"""Acceptance checks that cannot disappear under Python optimization."""
import sys

if sys.flags.optimize:
    raise RuntimeError("Certification requires optimize=0; unset PYTHONOPTIMIZE and omit -O/-OO")


def require(condition, message):
    """Reject a failed mathematical or implementation condition explicitly."""
    if not condition:
        raise RuntimeError("Certification check failed: " + str(message))
