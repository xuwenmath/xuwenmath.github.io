"""Supplementary implementation checks; not a substitute for the proof bounds.

Run after run_fresh.py, or set CERT_DATA to a freshly verified table directory.
"""
from certification_checks import require
from pathlib import Path
from fractions import Fraction as F
import os,sys,json
import numpy as np
ROOT=Path(__file__).resolve().parent
if 'CERT_DATA' not in os.environ:
    os.environ['CERT_DATA']=str(Path((ROOT/'latest_run.txt').read_text().strip())/'data')
import verify as v
folder,n,w,base,sin=v.table_values('tables')
checks=[]
for m in [2,6,30,62]:
    ids=np.flatnonzero((v.ML[:,0]==m)&(v.ML[:,1]<=64))
    p=base[:,ids];factor=w*v.Ball.endpoints(*v.PI_BRACKET)
    gram=p.T.mm(p*v.Ball(factor.m[:,None],factor.r[:,None]))
    err=gram-np.eye(len(ids))
    require(np.all(err.lo()<=0) and np.all(err.hi()>=0), 'np.all(err.lo()<=0) and np.all(err.hi()>=0)')
    checks.append({'kind':'base_Gram','m':m,'dimension':len(ids),'error_upper':v.frob(err)})
manifest={tuple(x[:2]):x[2] for x in json.loads((folder/'manifest.json').read_text())['pairs']}
for a,b in [(0,0),(2,0),(15,0),(40,40),(1,14)]:
    p=v.load_radial(a,b,manifest[tuple(sorted((a,b)))],n,folder,manifest)
    gram=p.T.mm(p*v.Ball(w.m[:,None],w.r[:,None]));err=gram-np.eye(p.m.shape[1])
    require(np.all(err.lo()<=0) and np.all(err.hi()>=0), 'np.all(err.lo()<=0) and np.all(err.hi()>=0)')
    checks.append({'kind':'charge_radial_Gram','a':a,'b':b,'dimension':p.m.shape[1],'error_upper':v.frob(err)})
rng=np.random.default_rng(4567);count=0
for k in [1,3,17,100]:
    a=rng.standard_normal((3,k));b=rng.standard_normal((k,3))
    ar=rng.random((3,k))*1e-10;br=rng.random((k,3))*1e-10
    c=v.Ball(a,ar).mm(v.Ball(b,br))
    for i in range(3):
        for j in range(3):
            lo=hi=F(0)
            for z in range(k):
                aa=[F(a[i,z])-F(ar[i,z]),F(a[i,z])+F(ar[i,z])]
                bb=[F(b[z,j])-F(br[z,j]),F(b[z,j])+F(br[z,j])]
                products=[x*y for x in aa for y in bb]
                lo+=min(products);hi+=max(products)
            require(F(c.m[i,j])-F(c.r[i,j])<=lo<=hi<=F(c.m[i,j])+F(c.r[i,j]), 'F(c.m[i,j])-F(c.r[i,j])<=lo<=hi<=F(c.m[i,j])+F(c.r[i,j])')
            count+=1
out={'status':'passed','role':'targeted implementation audit, not a replacement for the analytic error proof','exact_rational_dot_enclosures':count,'orthogonality_checks':checks}
(v.DATA/'supplementary_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
