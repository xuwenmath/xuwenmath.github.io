"""Exact rational closure; run only after a fresh full certificate run."""
from certification_checks import require
from fractions import Fraction as F
from pathlib import Path
import json, os, hashlib
ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('CERT_DATA',str(ROOT/'data')))
def read(n):
    obj=json.loads((DATA/n).read_text());require(obj.get('pass') is True, n + ': pass must be true')
    return obj
r=read('residual.json');s=read('sup_bridge.json');b=read('base_inverse.json')
charges=[read(f'charge_{m:02}.json') for m in range(26)]
require(F(r['residual_L2_upper'])<F(1,5000000), "F(r['residual_L2_upper'])<F(1,5000000)")
require(F(s['candidate_sup_upper'])<F(673,200), "F(s['candidate_sup_upper'])<F(673,200)")
require(F(s['bridge_upper'])<F(1,2000000), "F(s['bridge_upper'])<F(1,2000000)")
require(F(s['center_lower'])>3, "F(s['center_lower'])>3")
require(F(b['full_inverse_upper'])<F(3,50), "F(b['full_inverse_upper'])<F(3,50)")
tau=4*65*66+F(3,4)-5*F(673,200)**4
require(b['tail_exact']==str(tau), 'exact base-tail value')
require(0<F(b['tail_lower'])<=tau, 'base-tail lower enclosure')
Mb=F(673,200);M=F(337,100);rho=F(1,100000);Cs=F(3,20)
Cb=F(2,7)*(1+5*Mb**4*F(3,50))
k=20*Cb*M**3*Cs*rho
selfmap=Cb*F(1,5000000)+k*rho
require(M>Mb+Cs*rho and k<1 and selfmap<rho, 'M>Mb+Cs*rho and k<1 and selfmap<rho')
sigma=Cs*rho+F(1,2000000)
require(sigma==F(1,500000), 'sigma==F(1,500000)')
for m,d in enumerate(charges):
    require(d['charge']==m and len(d['blocks'])==4, "d['charge']==m and len(d['blocks'])==4")
    require(d['lifted_rank']=={0:3,1:2,2:1}.get(m,0), "d['lifted_rank']=={0:3,1:2,2:1}.get(m,0)")
    for block in d['blocks']:
        require(F(block['eta_upper'])<F(3,5), "F(block['eta_upper'])<F(3,5)")
        require(F(block['T_upper'])<5, "F(block['T_upper'])<5")
rank=charges[0]['lifted_rank']+2*sum(d['lifted_rank'] for d in charges[1:])
require(rank==9, 'rank==9')
high=26**2+F(3,4)-5*M**4
require(high>0 and 1/high<5, 'high>0 and 1/high<5')
delta=F(3,5)+20*M**3*sigma*5
require(delta<1, 'delta<1')
def rat(x):return {'exact':str(x),'decimal_display':float(x)}
out={'pass':True,'low_charge_blocks':104,'rank_complex':rank,
 'newton_Cb':rat(Cb),'newton_k':rat(k),'newton_selfmap_radius':rat(selfmap),
 'rho':rat(rho),'sigma':rat(sigma),'high_charge_lower':rat(high),
 'eta_budget':rat(F(3,5)),'T_budget':rat(F(5)),'perturbed_delta':rat(delta),
 'strict_margin':rat(1-delta),
 'max_eta_observed':max(d['eta_upper'] for d in charges),
 'max_T_observed':max(d['T_upper'] for d in charges),
 'input_sha256':hashlib.sha256((ROOT/'inputs/candidate_coefficients.hex').read_bytes()).hexdigest(),
 'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['verify.py','interval_backend.cpp','aggregate.py','certification_checks.py','run_fresh.py','audit_checks.py','regression_checks.py']}}
(DATA/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
