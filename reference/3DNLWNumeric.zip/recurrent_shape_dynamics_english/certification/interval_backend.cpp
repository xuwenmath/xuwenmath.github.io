// Directed-rounding MPFR interval backend and auditable finite matrix products.
// Build: g++ -O2 -std=c++17 -shared -fPIC -fopenmp -fno-fast-math
//        -ffp-contract=off interval_backend.cpp -Wl,-l:libmpfr.so.6 -lgmp -o backend.so
// Minimal stable MPFR ABI declarations: the installed runtime lacks mpfr.h.
#include <gmp.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cfloat>
#include <cfenv>
#include <algorithm>
#include <vector>
#include <string>
#include <fstream>
#include <stdexcept>
#include <limits>
extern "C" {
typedef long mpfr_prec_t; typedef long mpfr_exp_t;
typedef struct {mpfr_prec_t _mpfr_prec; int _mpfr_sign; mpfr_exp_t _mpfr_exp; mp_limb_t *_mpfr_d;} __mpfr_struct;
typedef __mpfr_struct mpfr_t[1]; typedef __mpfr_struct *mpfr_ptr; typedef const __mpfr_struct *mpfr_srcptr;
typedef enum {MPFR_RNDN=0,MPFR_RNDZ,MPFR_RNDU,MPFR_RNDD,MPFR_RNDA,MPFR_RNDF} mpfr_rnd_t;
void mpfr_init2(mpfr_ptr,mpfr_prec_t); void mpfr_clear(mpfr_ptr);
int mpfr_set(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_set_d(mpfr_ptr,double,mpfr_rnd_t);
int mpfr_set_si(mpfr_ptr,long,mpfr_rnd_t); int mpfr_set_ui_2exp(mpfr_ptr,unsigned long,mpfr_exp_t,mpfr_rnd_t);
int mpfr_add(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_sub(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_mul(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_div(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_sqrt(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_pow_ui(mpfr_ptr,mpfr_srcptr,unsigned long,mpfr_rnd_t);
int mpfr_sin(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_cos(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_const_pi(mpfr_ptr,mpfr_rnd_t); int mpfr_fac_ui(mpfr_ptr,unsigned long,mpfr_rnd_t);
double mpfr_get_d(mpfr_srcptr,mpfr_rnd_t); int mpfr_cmp(mpfr_srcptr,mpfr_srcptr); int mpfr_cmp_si(mpfr_srcptr,long);
const char *mpfr_get_version(void);
}
static thread_local int precision=256;
static constexpr auto DN=MPFR_RNDD, UP=MPFR_RNDU, RN=MPFR_RNDN;
struct I {
 mpfr_t lo,hi;
 I(){mpfr_init2(lo,precision);mpfr_init2(hi,precision);mpfr_set_si(lo,0,RN);mpfr_set_si(hi,0,RN);}
 I(double x):I(){mpfr_set_d(lo,x,DN);mpfr_set_d(hi,x,UP);}
 I(const I&x):I(){mpfr_set(lo,x.lo,DN);mpfr_set(hi,x.hi,UP);}
 I&operator=(const I&x){if(this!=&x){mpfr_set(lo,x.lo,DN);mpfr_set(hi,x.hi,UP);}return *this;}
 ~I(){mpfr_clear(lo);mpfr_clear(hi);}
 double lower()const{return mpfr_get_d(lo,DN);} double upper()const{return mpfr_get_d(hi,UP);}
};
I operator+(const I&a,const I&b){I r;mpfr_add(r.lo,a.lo,b.lo,DN);mpfr_add(r.hi,a.hi,b.hi,UP);return r;}
I operator-(const I&a,const I&b){I r;mpfr_sub(r.lo,a.lo,b.hi,DN);mpfr_sub(r.hi,a.hi,b.lo,UP);return r;}
I operator*(const I&a,const I&b){
 I r,t;mpfr_mul(r.lo,a.lo,b.lo,DN);mpfr_mul(r.hi,a.lo,b.lo,UP);
 mpfr_srcptr aa[2]={a.lo,a.hi},bb[2]={b.lo,b.hi};
 for(int i=0;i<2;i++)for(int j=0;j<2;j++){
  mpfr_mul(t.lo,aa[i],bb[j],DN);mpfr_mul(t.hi,aa[i],bb[j],UP);
  if(mpfr_cmp(t.lo,r.lo)<0)mpfr_set(r.lo,t.lo,DN);
  if(mpfr_cmp(t.hi,r.hi)>0)mpfr_set(r.hi,t.hi,UP);
 }return r;
}
I operator/(const I&a,const I&b){
 if(mpfr_cmp_si(b.lo,0)<=0&&mpfr_cmp_si(b.hi,0)>=0)throw std::runtime_error("interval division by zero");
 I one(1),r;mpfr_div(r.lo,one.lo,b.hi,DN);mpfr_div(r.hi,one.hi,b.lo,UP);return a*r;
}
I sqrti(const I&a){if(mpfr_cmp_si(a.lo,0)<0)throw std::runtime_error("negative sqrt");I r;mpfr_sqrt(r.lo,a.lo,DN);mpfr_sqrt(r.hi,a.hi,UP);return r;}
I power(const I&a,unsigned n){
 I r;
 if(n%2 || mpfr_cmp_si(a.lo,0)>=0){mpfr_pow_ui(r.lo,a.lo,n,DN);mpfr_pow_ui(r.hi,a.hi,n,UP);}
 else if(mpfr_cmp_si(a.hi,0)<=0){mpfr_pow_ui(r.lo,a.hi,n,DN);mpfr_pow_ui(r.hi,a.lo,n,UP);}
 else {I t;mpfr_pow_ui(r.hi,a.lo,n,UP);mpfr_pow_ui(t.hi,a.hi,n,UP);if(mpfr_cmp(t.hi,r.hi)>0)mpfr_set(r.hi,t.hi,UP);}
 return r;
}
I pi(){I r;mpfr_const_pi(r.lo,DN);mpfr_const_pi(r.hi,UP);return r;}
I factorial(unsigned n){I r;mpfr_fac_ui(r.lo,n,DN);mpfr_fac_ui(r.hi,n,UP);return r;}
I trig(const I&a,bool cosine){
 // Evaluate at an exact representable center; the derivative has modulus <= 1.
 I mid=(a+I(0))/I(1), t;
 mpfr_add(mid.lo,a.lo,a.hi,RN);mpfr_div(mid.lo,mid.lo,I(2).lo,RN);mpfr_set(mid.hi,mid.lo,RN);
 I rad1=mid-a,rad2=a-mid;I radius;
 mpfr_set(radius.hi,mpfr_cmp(rad1.hi,rad2.hi)>0?rad1.hi:rad2.hi,UP);
 if(cosine){mpfr_cos(t.lo,mid.lo,DN);mpfr_cos(t.hi,mid.hi,UP);}else{mpfr_sin(t.lo,mid.lo,DN);mpfr_sin(t.hi,mid.hi,UP);}
 mpfr_sub(t.lo,t.lo,radius.hi,DN);mpfr_add(t.hi,t.hi,radius.hi,UP);return t;
}
std::vector<I> jacobi(const I&x,int a,int b,int n){
 std::vector<I> p(n+1);p[0]=I(1);if(n==0)return p;
 p[1]=(I(a-b)+I(a+b+2)*x)/I(2);
 for(int j=2;j<=n;j++){
  double s=2*j+a+b;
  p[j]=(I(s-1)*(I(s*(s-2))*x+I(a*a-b*b))*p[j-1]
       -I(2.0*(j+a-1)*(j+b-1)*s)*p[j-2])/I(2.0*j*(j+a+b)*(s-2));
 }return p;
}
std::pair<I,I> legendre(const I&x,int n){
 I pm(1),p=x;
 if(n==0)return {pm,I(0)};
 for(int j=2;j<=n;j++){I next=(I(2*j-1)*x*p-I(j-1)*pm)/I(j);pm=p;p=next;}
 I deriv=I(n)*(pm-x*p)/(I(1)-x*x);return {p,deriv};
}
I point(mpfr_srcptr x){I y;mpfr_set(y.lo,x,RN);mpfr_set(y.hi,x,RN);return y;}
// This Newton iteration proposes roots only. The two sign tests below certify them.
I root_proposal(double seed,int n){
 I x(seed);
 for(int k=0;k<9;k++){
  // Point recurrence with nearest rounding avoids wrapping in the proposal.
  mpfr_t pm,p,t,u,der,next;mpfr_init2(pm,precision);mpfr_init2(p,precision);mpfr_init2(t,precision);mpfr_init2(u,precision);mpfr_init2(der,precision);mpfr_init2(next,precision);
  mpfr_set_si(pm,1,RN);mpfr_set(p,x.lo,RN);
  for(int j=2;j<=n;j++){
   mpfr_mul(t,x.lo,p,RN);mpfr_mul(t,t,I(2*j-1).lo,RN);mpfr_mul(u,pm,I(j-1).lo,RN);mpfr_sub(t,t,u,RN);mpfr_div(next,t,I(j).lo,RN);
   mpfr_set(pm,p,RN);mpfr_set(p,next,RN);
  }
  mpfr_mul(t,x.lo,p,RN);mpfr_sub(t,pm,t,RN);mpfr_mul(t,t,I(n).lo,RN);
  mpfr_mul(u,x.lo,x.lo,RN);mpfr_sub(u,I(1).lo,u,RN);mpfr_div(der,t,u,RN);
  mpfr_div(t,p,der,RN);mpfr_sub(x.lo,x.lo,t,RN);mpfr_set(x.hi,x.lo,RN);
  mpfr_clear(pm);mpfr_clear(p);mpfr_clear(t);mpfr_clear(u);mpfr_clear(der);mpfr_clear(next);
 }return x;
}
void write_interval(std::ofstream&f,const I&x){double a[2]={x.lower(),x.upper()};f.write(reinterpret_cast<char*>(a),sizeof(a));}
static std::string last_error;
extern "C" const char* backend_error(){return last_error.c_str();}
extern "C" const char* backend_version(){return mpfr_get_version();}
extern "C" int generate_tables(const char* dirname,const double* seeds,int n,int nphi,const int* pairs,int npairs,const int* ml,int nbase){
 try{
  std::string d(dirname);precision=2048;std::vector<I> nodes,weights;nodes.reserve(n);weights.reserve(n);
  I tiny;mpfr_set_ui_2exp(tiny.lo,1,-1000,RN);mpfr_set(tiny.hi,tiny.lo,RN);
  for(int k=0;k<n;k++){
   I x=root_proposal(seeds[k],n),left=x-tiny,right=x+tiny;
   I pl=legendre(point(left.lo),n).first,pr=legendre(point(right.hi),n).first;
   if(!((mpfr_cmp_si(pl.hi,0)<0&&mpfr_cmp_si(pr.lo,0)>0)||(mpfr_cmp_si(pl.lo,0)>0&&mpfr_cmp_si(pr.hi,0)<0)))throw std::runtime_error("Legendre root sign verification failed at "+std::to_string(k));
   I enclosure;mpfr_set(enclosure.lo,left.lo,DN);mpfr_set(enclosure.hi,right.hi,UP);
   if(mpfr_cmp_si(enclosure.lo,-1)<=0||mpfr_cmp_si(enclosure.hi,1)>=0)throw std::runtime_error("root outside (-1,1)");
   if(k&&mpfr_cmp(nodes.back().hi,enclosure.lo)>=0)throw std::runtime_error("overlapping root intervals");
   nodes.push_back(enclosure);I deriv=legendre(enclosure,n).second;
   weights.push_back(I(2)/((I(1)-power(enclosure,2))*power(deriv,2)));
  }
  std::ofstream wf(d+"/quadrature.bin",std::ios::binary);for(int k=0;k<n;k++){write_interval(wf,nodes[k]);write_interval(wf,weights[k]);}wf.close();
  precision=256;
  std::vector<I> basenorm;basenorm.reserve(nbase);
  for(int k=0;k<nbase;k++){int m=ml[2*k],l=ml[2*k+1];basenorm.push_back(sqrti(I(2*l+1)*factorial(l-m)*factorial(l+m)/(I(2)*pi()))/(factorial(l)*power(I(2),m)));}
  std::ofstream bf(d+"/base.bin",std::ios::binary);
  for(int k=0;k<n;k++){
   I x(nodes[k]);int offset=0;
   while(offset<nbase){int m=ml[2*offset],end=offset;while(end<nbase&&ml[2*end]==m)end++;
    int lm=ml[2*(end-1)+1];auto p=jacobi(x,m,m,lm-m);I radial=power(I(1)-power(x,2),m/2);
    for(int j=offset;j<end;j++)write_interval(bf,basenorm[j]*radial*p[ml[2*j+1]-m]);offset=end;
   }
  }bf.close();
  std::ofstream trigf(d+"/trig.bin",std::ios::binary);
  // Entire DFT table, with intervals for cos(k*phi). Only real coefficients are needed.
  for(int k=0;k<nphi;k++)for(int j=0;j<=128;j++)write_interval(trigf,trig(I(2.0*k*j)*pi()/I(nphi),true));
  trigf.close();
  std::ofstream sf(d+"/sin.bin",std::ios::binary);
  for(int j=0;j<nbase;){int m=ml[2*j];for(int k=0;k<nphi;k++)write_interval(sf,trig(I(2.0*k*m)*pi()/I(nphi),false));while(j<nbase&&ml[2*j]==m)j++;}sf.close();
  #pragma omp parallel for schedule(dynamic,1)
  for(int pair=0;pair<npairs;pair++){
   int a=pairs[3*pair],b=pairs[3*pair+1],jmax=pairs[3*pair+2];
   std::vector<I> norms;for(int j=0;j<=jmax;j++)norms.push_back(sqrti(I(2*j+a+b+1)*factorial(j)*factorial(j+a+b)/(I(2)*factorial(j+a)*factorial(j+b))));
   std::ofstream f(d+"/radial_"+std::to_string(a)+"_"+std::to_string(b)+".bin",std::ios::binary);
   for(int k=0;k<n;k++){
    I x(nodes[k]);auto ps=jacobi(x,a,b,jmax);
    I pref=sqrti(power((I(1)-x)/I(2),a)*power((I(1)+x)/I(2),b));
    for(int j=0;j<=jmax;j++)write_interval(f,pref*ps[j]*norms[j]);
   }
  }
  return 0;
 }catch(const std::exception&e){last_error=e.what();return -1;}
}

extern "C" int generate_grid(const char*dirname,int nt,int np,const int*ml,int nb){
 try{
  precision=256;std::string d(dirname);std::vector<I> norms;
  for(int k=0;k<nb;k++){int m=ml[2*k],l=ml[2*k+1];norms.push_back(sqrti(I(2*l+1)*factorial(l-m)*factorial(l+m)/(I(2)*pi()))/(factorial(l)*power(I(2),m)));}
  std::ofstream f(d+"/grid_base.bin",std::ios::binary);
  for(int k=0;k<=nt;k++){
   I x=trig(I(k)*pi()/I(nt),true);
   // Exact endpoints avoid a negative enclosure of 1-x^2 at the poles.
   if(k==0)x=I(1);if(k==nt)x=I(-1);
   int offset=0;
   while(offset<nb){int m=ml[2*offset],end=offset;while(end<nb&&ml[2*end]==m)end++;
    auto ps=jacobi(x,m,m,ml[2*(end-1)+1]-m);I pref=power(I(1)-power(x,2),m/2);
    for(int j=offset;j<end;j++)write_interval(f,norms[j]*pref*ps[ml[2*j+1]-m]);offset=end;
   }
  }f.close();
  std::ofstream sf(d+"/grid_sin.bin",std::ios::binary);
  for(int j=0;j<nb;){int m=ml[2*j];for(int k=0;k<np;k++)write_interval(sf,trig(I(2.0*k*m)*pi()/I(np),false));while(j<nb&&ml[2*j]==m)j++;}sf.close();
  return 0;
 }catch(const std::exception&e){last_error=e.what();return -1;}
}

// Inputs are midpoint-radius real matrices. Computation uses long double with
// at least 64 significand bits. A deliberately loose gamma bound encloses all
// rounding in the known dot-product loop; no BLAS error model is needed.
extern "C" int verified_product(const double*A,const double*Ar,const double*B,const double*Br,double*C,double*Cr,int m,int n,int k){
 static_assert(LDBL_MANT_DIG>=64,"requires >=64-bit long double significand");
 if(std::fegetround()!=FE_TONEAREST)return -2;
 if(k<1||k>100000||m<1||n<1)return -1;
 const long double gamma=std::ldexp((long double)(32*(k+4)),-64);
 #pragma omp parallel for schedule(static)
 for(int i=0;i<m;i++)for(int j=0;j<n;j++){
  long double s=0,ab=0,rad=0;
  for(int z=0;z<k;z++){
   long double a=A[(size_t)i*k+z],b=B[(size_t)z*n+j],ar=Ar[(size_t)i*k+z],br=Br[(size_t)z*n+j];
   long double p=a*b;s+=p;ab+=std::abs(p);
   rad+=std::abs(a)*br+std::abs(b)*ar+ar*br;
  }
  double c=(double)s;
  long double err=gamma*(ab+rad)+2*rad+2*std::abs(s-(long double)c)+1e-290L;
  C[(size_t)i*n+j]=c;Cr[(size_t)i*n+j]=std::nextafter((double)err,INFINITY);
 }
 return 0;
}
