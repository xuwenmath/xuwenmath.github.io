"""Rebuild and recompute every enclosure in a new, empty run directory."""
from certification_checks import require
from pathlib import Path
from datetime import datetime, timezone
import subprocess, os, sys, json, platform, hashlib

ROOT=Path(__file__).resolve().parent
run=ROOT/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
run.mkdir(parents=True,exist_ok=False)
env=os.environ.copy()
# A parent started with -E can have an ignored PYTHONOPTIMIZE in its environment.
# Do not let that setting reach any child interpreter.
env.pop('PYTHONOPTIMIZE',None)
env['CERT_DATA']=str(run/'data')
env['OPENBLAS_NUM_THREADS']='1'
env['OMP_NUM_THREADS']=env.get('OMP_NUM_THREADS','8')
compile_cmd=['g++','-O2','-std=c++17','-shared','-fPIC','-fopenmp','-fno-fast-math','-ffp-contract=off','interval_backend.cpp','-Wl,-l:libmpfr.so.6','-lgmp','-o','backend.so']
stages=['tables','residual','grid','check_residual','check_grid','check_main']
print('Fresh certificate run:',run,flush=True)
with (run/'verification.log').open('w') as log:
    def execute(label, command):
        print('RUNNING',label,flush=True)
        print('RUNNING',label,flush=True,file=log)
        print('COMMAND',json.dumps(command),flush=True,file=log)
        subprocess.run(command,cwd=ROOT,env=env,stdout=log,
                       stderr=subprocess.STDOUT,check=True)
        print('PASSED',label,flush=True,file=log)
    execute('compile_backend',compile_cmd)
    for stage in stages:
        execute(stage,[sys.executable,'verify.py',stage])
    for script in ['aggregate.py','audit_checks.py','regression_checks.py']:
        execute(script,[sys.executable,script])
    print('ALL CHECKS PASSED',flush=True,file=log)

import numpy, scipy
manifest=json.loads((run/'data/tables/manifest.json').read_text())
meta={'run_id':run.name,'platform':platform.platform(),'machine':platform.machine(),
 'python':sys.version,'python_optimize':sys.flags.optimize,
 'numpy':numpy.__version__,'scipy':scipy.__version__,'mpfr':manifest['mpfr'],
 'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
 'compile_command':compile_cmd,
 'environment':{k:env[k] for k in ['CERT_DATA','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS']},
 'log_sha256':hashlib.sha256((run/'verification.log').read_bytes()).hexdigest()}
(run/'environment.json').write_text(json.dumps(meta,indent=2)+'\n')
(ROOT/'latest_run.txt').write_text(str(run)+'\n')
print((run/'data/summary.json').read_text(),flush=True)
print('ALL CHECKS PASSED',flush=True)
