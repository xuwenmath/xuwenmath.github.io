"""Negative controls for optimization bypass and directed lower rounding.

Run after aggregate.py with CERT_DATA set, or after run_fresh.py.
Only temporary report copies are deliberately corrupted.
"""
from certification_checks import require
from pathlib import Path
from fractions import Fraction
import ast, json, os, shutil, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent
if 'CERT_DATA' not in os.environ:
    os.environ['CERT_DATA']=str(Path((ROOT/'latest_run.txt').read_text().strip())/'data')
DATA=Path(os.environ['CERT_DATA'])
import verify as v

entries={
    'verify.py':['check_residual'],
    'aggregate.py':[],
    'run_fresh.py':[],
    'audit_checks.py':[],
    'regression_checks.py':[],
}
modes=[('minus_O',['-O'],None),('minus_OO',['-OO'],None),
       ('environment_1',[],'1'),('environment_2',[],'2')]
checks=[]
for name in [*entries,'certification_checks.py']:
    require(not any(isinstance(node,ast.Assert)
                    for node in ast.walk(ast.parse((ROOT/name).read_text()))),
            name+': no optimization-sensitive assertions')

def invoke(name, args, folder, flags=(), opt=None):
    env=os.environ.copy()
    env.pop('PYTHONOPTIMIZE',None)
    if opt is not None:env['PYTHONOPTIMIZE']=opt
    env['CERT_DATA']=str(folder)
    return subprocess.run([sys.executable,*flags,str(ROOT/name),*args],
                          cwd=ROOT,env=env,text=True,capture_output=True)

def record(label, result, expected_message=None, accept=False):
    output=result.stdout+result.stderr
    require((result.returncode==0) if accept else (result.returncode!=0),label)
    if expected_message is not None:require(expected_message in output,label)
    if not accept:require('"pass": true' not in result.stdout,label+': no false success')
    checks.append({'case':label,'exit_code':result.returncode,
                   'expected_outcome':'accept' if accept else 'reject',
                   'diagnostic':output.strip().splitlines()[-1] if not accept else 'valid report set accepted'})

temp_root=ROOT/'runs'
temp_root.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='negative-controls-',dir=temp_root) as tmp:
    fixture=Path(tmp)/'reports';fixture.mkdir()
    for path in DATA.glob('*.json'):shutil.copy2(path,fixture/path.name)
    residual=json.loads((fixture/'residual.json').read_text())
    record('valid_report_set',invoke('aggregate.py',[],fixture),accept=True)
    for name,args in entries.items():
        for mode,flags,opt in modes:
            record(name+':'+mode,invoke(name,args,fixture,flags,opt),
                   'Certification requires optimize=0')
    mutations=[('false_pass',{'pass':False}),
               ('excessive_residual',{'residual_L2_upper':1.0}),
               ('false_pass_and_excessive_residual',{'pass':False,'residual_L2_upper':1.0})]
    for label,patch in mutations:
        damaged={**residual,**patch}
        (fixture/'residual.json').write_text(json.dumps(damaged))
        record(label+':normal',invoke('aggregate.py',[],fixture),
               'Certification check failed:')
        for mode,flags,opt in modes:
            record(label+':'+mode,invoke('aggregate.py',[],fixture,flags,opt),
                   'Certification requires optimize=0')

tau=4*65*66+Fraction(3,4)-5*Fraction(673,200)**4
old=Fraction.from_float(float(tau))
new=Fraction.from_float(v.fraction_down(tau))
require(old>tau,'negative control must reproduce the old upward rounding')
require(new<=tau,'corrected tail lower enclosure')
report=json.loads((DATA/'base_inverse.json').read_text())
require(Fraction.from_float(report['tail_lower'])==new,'recorded tail lower enclosure')
require(report['tail_exact']==str(tau),'recorded exact tail')
for x in [Fraction(0),Fraction(1,10),Fraction(-1,10),Fraction(5,7),Fraction(-5,7),tau]:
    require(Fraction.from_float(v.fraction_down(x))<=x,'signed rational lower rounding')

out={'status':'passed','role':'release regression checks; not a proof-assistant formalization',
     'subprocess_cases':len(checks),'cases':checks,
     'tail_rounding':{'exact':str(tau),'old_float_minus_exact':str(old-tau),
                      'new_lower':float(new),'exact_minus_new_lower':str(tau-new)},
     'assertion_free_certificate_entries':True}
(DATA/'regression_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
