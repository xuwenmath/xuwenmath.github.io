"""Computer-assisted stationary and full spherical kernel certificate.

Floating eigensolvers/inverses propose matrices ONLY. Every result is checked
using the MPFR interval tables and the explicit verified dot-product loop.
Run with OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=8.
"""
from certification_checks import require
from pathlib import Path
import ctypes as ct
import json, math, argparse, time, hashlib, os
from fractions import Fraction
import numpy as np
from scipy.special import roots_legendre
from scipy.linalg import eigh

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('CERT_DATA',str(ROOT/'data'))); DATA.mkdir(parents=True,exist_ok=True)
lib=ct.CDLL(str(ROOT/'backend.so'))
dp=ct.POINTER(ct.c_double); ip=ct.POINTER(ct.c_int)
lib.generate_tables.argtypes=[ct.c_char_p,dp,ct.c_int,ct.c_int,ip,ct.c_int,ip,ct.c_int]
lib.generate_grid.argtypes=[ct.c_char_p,ct.c_int,ct.c_int,ip,ct.c_int]
lib.verified_product.argtypes=[dp,dp,dp,dp,dp,dp,ct.c_int,ct.c_int,ct.c_int]
lib.backend_error.restype=ct.c_char_p;lib.backend_version.restype=ct.c_char_p
ML=np.array([(m,l) for m in range(2,97,4) for l in range(m,97,2)],dtype=np.int32)
GROUPS=sorted(set(ML[:,0])); NB=len(ML)
up=lambda x:np.nextafter(x,np.inf)
down=lambda x:np.nextafter(x,-np.inf)
def ptr(a):return a.ctypes.data_as(dp)
def iptr(a):return a.ctypes.data_as(ip)
def log(*args):print(*args,flush=True)

class Ball:
    def __init__(self,m,r=0.):
        self.m=np.ascontiguousarray(np.asarray(m,dtype=float))
        self.r=np.ascontiguousarray(np.broadcast_to(np.asarray(r,dtype=float),self.m.shape))
        require(np.all(np.isfinite(self.m)) and np.all(np.isfinite(self.r)) and np.all(self.r>=0), 'np.all(np.isfinite(self.m)) and np.all(np.isfinite(self.r)) and np.all(self.r>=0)')
    @classmethod
    def endpoints(cls,a,b):
        a=np.asarray(a);b=np.asarray(b)
        require(np.all(a<=b), 'np.all(a<=b)')
        m=a+(b-a)*.5
        r=up(np.maximum(up(m-a),up(b-m)))
        return cls(m,r)
    def lo(self):return down(self.m-self.r)
    def hi(self):return up(self.m+self.r)
    def __getitem__(self,k):return Ball(self.m[k],self.r[k])
    @property
    def T(self):return Ball(self.m.T,self.r.T)
    def __add__(self,o):
        if not isinstance(o,Ball):o=Ball(o)
        return Ball.endpoints(down(self.lo()+o.lo()),up(self.hi()+o.hi()))
    def __neg__(self):return Ball(-self.m,self.r)
    def __sub__(self,o):return self+-o if isinstance(o,Ball) else self+Ball(-np.asarray(o))
    def __mul__(self,o):
        if not isinstance(o,Ball):o=Ball(o)
        a,b,c,d=self.lo(),self.hi(),o.lo(),o.hi()
        vals=np.array([a*c,a*d,b*c,b*d])
        return Ball.endpoints(down(np.min(vals,axis=0)),up(np.max(vals,axis=0)))
    def power(self,n):
        require(n>=1, 'n>=1')
        a,b=self.lo(),self.hi()
        if n==1:return self
        # Repeated interval multiplication avoids libm pow accuracy assumptions.
        out=Ball(np.ones_like(self.m))
        for _ in range(n):out=out*self
        if n%2==0:
            out=Ball.endpoints(np.maximum(0,out.lo()),out.hi())
        return out
    def abs_upper(self):return up(np.abs(self.m)+self.r)
    def mm(self,o):
        require(self.m.ndim==2 and o.m.ndim==2 and self.m.shape[1]==o.m.shape[0], 'self.m.ndim==2 and o.m.ndim==2 and self.m.shape[1]==o.m.shape[0]')
        m,k=self.m.shape;n=o.m.shape[1]
        c=np.empty((m,n));r=np.empty((m,n))
        rc=lib.verified_product(ptr(self.m),ptr(self.r),ptr(o.m),ptr(o.r),ptr(c),ptr(r),m,n,k)
        if rc:raise RuntimeError('verified dot product failed')
        return Ball(c,r)

def psum(x,axis=None):
    """Upper bound for a nonnegative sum using a conservative binary64 gamma."""
    x=np.asarray(x,dtype=float);require(np.all(x>=0), 'np.all(x>=0)')
    n=x.size if axis is None else x.shape[axis]
    require(n<1e8, 'n<1e8')
    # Addition tree has depth <= n. This factor exceeds 1/(1-gamma_n).
    return up(np.sum(x,axis=axis)*(1+4*n*2.**-53))
def sqrt_up(x):
    # sqrt is IEEE correctly rounded on this platform; a second check uses
    # exact rational arithmetic for scalar outputs used in final inequalities.
    a=up(np.sqrt(x))
    if np.ndim(x)==0:
        while Fraction(float(a))**2<Fraction(float(x)):a=up(a)
    return a
def sqrt_fraction_bounds(x):
    x=Fraction(x);require(x>=0, 'x>=0')
    c=math.sqrt(float(x));lo=hi=c
    while Fraction(lo)**2>x:lo=float(down(lo))
    while Fraction(hi)**2<x:hi=float(up(hi))
    return Fraction(lo),Fraction(hi)
def fraction_up(x):
    x=Fraction(x);f=float(x)
    while Fraction(f)<x:f=float(up(f))
    return f
def fraction_down(x):
    """Convert an exact rational to a verified binary64 lower enclosure."""
    x=Fraction(x);f=float(x)
    while Fraction.from_float(f)>x:f=math.nextafter(f,-math.inf)
    require(Fraction.from_float(f)<=x, 'rational lower enclosure')
    return f

def verify_pi_bracket():
    def atan_bounds(k):
        s=sum((Fraction((-1)**j,(2*j+1)*k**(2*j+1)) for j in range(40)),Fraction(0))
        return s,s+Fraction(1,81*k**81)
    a,b=atan_bounds(5);c,d=atan_bounds(239)
    plo,phi=16*a-4*d,16*b-4*c
    lo=float.fromhex('0x1.921fb54442d18p+1');hi=float(up(lo))
    require(Fraction(lo)<plo<phi<Fraction(hi), 'Fraction(lo)<plo<phi<Fraction(hi)')
    return lo,hi
PI_BRACKET=verify_pi_bracket()
def frob(b):return float(sqrt_up(psum(up(b.abs_upper()*b.abs_upper()))))
def scalar_upper(x):return float(up(x))

def coeffs():
    src=ROOT/'inputs'
    exact=src/'candidate_coefficients.hex'
    if exact.exists():
        rows=[x.split() for x in exact.read_text().splitlines() if x and not x.startswith('#')]
        require([(int(x[0]),int(x[1])) for x in rows]==[tuple(map(int,x)) for x in ML], '[(int(x[0]),int(x[1])) for x in rows]==[tuple(map(int,x)) for x in ML]')
        return np.array([float.fromhex(x[2]) for x in rows]),np.array([float.fromhex(x[3]) for x in rows])
    d96=json.loads((src/'base_96.json').read_text())
    d64=json.loads((src/'base_64.json').read_text())
    def expand(d):
        vals={}
        for m,cs in zip(range(2,d['degree']+1,4),d['coefficients']):
            for l,c in zip(range(m,d['degree']+1,2),cs):vals[m,l]=float(c)
        return np.array([vals.get((int(m),int(l)),0.) for m,l in ML])
    return expand(d96),expand(d64)

def pair_list():
    pairs={}
    for m in range(26):
        N=112 if m in (2,15) else 80
        for l in range(math.ceil((m-N)/2),math.floor((m+N)/2)+1):
            a,b=sorted((abs(m-l),abs(l)))
            pairs[a,b]=max(pairs.get((a,b),-1),(N-a-b)//2)
    return np.array([(a,b,j) for (a,b),j in sorted(pairs.items())],dtype=np.int32)

def generate(stage):
    if stage in ('tables','residual'):
        n=400 if stage=='tables' else 500
        pairs=pair_list() if stage=='tables' else np.empty((0,3),dtype=np.int32)
        folder=DATA/stage;folder.mkdir(exist_ok=True)
        seeds=np.ascontiguousarray(roots_legendre(n)[0]);t=time.time()
        log('generating',stage,'n=',n,'MPFR',lib.backend_version().decode())
        rc=lib.generate_tables(str(folder).encode(),ptr(seeds),n,1024,iptr(pairs),len(pairs),iptr(ML),NB)
        if rc:raise RuntimeError(lib.backend_error().decode())
        (folder/'manifest.json').write_text(json.dumps({'n':n,'nphi':1024,'pairs':pairs.tolist(),'mpfr':lib.backend_version().decode(),'precision':256,'root_precision':2048}))
        log('generated',stage,'seconds',time.time()-t)
    else:
        folder=DATA/'grid';folder.mkdir(exist_ok=True);t=time.time()
        rc=lib.generate_grid(str(folder).encode(),2048,4096,iptr(ML),NB)
        if rc:raise RuntimeError(lib.backend_error().decode())
        log('generated grid seconds',time.time()-t)

def load_ball(file,shape):
    a=np.fromfile(file,dtype=float).reshape(*shape,2)
    return Ball.endpoints(a[...,0],a[...,1])
def grouped(base,cs):
    cols=[]
    for m in GROUPS:
        ids=np.flatnonzero(ML[:,0]==m)
        b=base[:,ids].mm(Ball(cs[ids,None]))
        cols.append(b)
    return Ball(np.hstack([b.m for b in cols]),np.hstack([b.r for b in cols]))
def evaluate(base,sin,cs):return grouped(base,cs).mm(sin)

def table_values(stage):
    folder=DATA/stage;n=400 if stage=='tables' else 500
    quad=np.fromfile(folder/'quadrature.bin').reshape(n,2,2)
    w=Ball.endpoints(quad[:,1,0],quad[:,1,1])
    base=load_ball(folder/'base.bin',(n,NB))
    sin=load_ball(folder/'sin.bin',(len(GROUPS),1024))
    return folder,n,w,base,sin

def verify_residual():
    _,n,w,base,sin=table_values('residual');c96,_=coeffs()
    v=evaluate(base,sin,c96)
    diag=4*ML[:,1]*(ML[:,1]+1)+.75
    # Multiplication by this dyadic diagonal is enclosed, not silently exact.
    ac=Ball(c96)*Ball(diag)
    av=grouped(base,ac.m).mm(sin)
    # grouped() accepts exact coefficients, so explicitly propagate ac radius.
    err=grouped(Ball(base.abs_upper()),ac.r).mm(Ball(sin.abs_upper()))
    av=Ball(av.m,up(av.r+err.abs_upper()))
    f=av-v.power(5)
    squares=up(f.abs_upper()*f.abs_upper())
    # 2*pi/nphi < 44/(7*nphi), used as an exact rational upper bound.
    raw=psum(up(squares*w.hi()[:,None]))
    r2=Fraction(float(raw))*Fraction(44,7*1024)
    r=float(sqrt_up(float(up(float(r2)))))
    require(Fraction(r)**2>=r2, 'Fraction(r)**2>=r2')
    result={'residual_L2_upper':r,'target':2e-7,'pass':r<2e-7,'max_value_interval_radius':float(np.max(v.r))}
    log('RESIDUAL',result);return result

def verify_sup_bridge():
    c96,c64=coeffs();base=load_ball(DATA/'grid/grid_base.bin',(2049,NB));sin=load_ball(DATA/'grid/grid_sin.bin',(len(GROUPS),4096))
    v=evaluate(base,sin,c96);sample=float(np.max(v.abs_upper()))
    # Addition theorem with pi>3 gives a rigorous individual harmonic bound.
    ybound=up(np.sqrt((2*ML[:,1]+1)/12.))
    # Verify all sqrt upper endpoints against exact rational radicands.
    for i,l in enumerate(ML[:,1]):
        while Fraction(float(ybound[i]))**2<Fraction(int(2*l+1),12):ybound[i]=up(ybound[i])
    terms=up(up(np.abs(c96)*ybound)*(ML[:,1].astype(float)**2))
    H=float(psum(terms));gap=Fraction(H)*Fraction(22,7)**2/Fraction(2*2048**2)
    sup=Fraction(sample)+gap
    diff=Ball(c96)-Ball(c64)
    bridge=float(psum(up(diff.abs_upper()*ybound)))
    center_lower=float(v.lo()[1024,512])
    result={'sample_upper':sample,'center_lower':center_lower,'hessian_upper':H,'grid_gap_upper':float(up(float(gap))),'candidate_sup_upper':float(up(float(sup))),'sup_target':3.365,'bridge_upper':bridge,'bridge_target':5e-7,'max_value_interval_radius':float(np.max(v.r)),'pass':sup<Fraction(673,200) and Fraction(bridge)<Fraction(1,2000000) and center_lower>3.}
    log('SUP_BRIDGE',result);return result

def finite_spectral_bound(A):
    """Rigorous norm bound and inverse bound from an untrusted eigendecomposition."""
    vals,U=eigh((A.m+A.m.T)*.5,check_finite=False)
    ub=Ball(U);gram=ub.T.mm(ub)-np.eye(len(vals));g=frob(gram)
    R=A.mm(ub)-ub*Ball(vals[None,:]);r=frob(R)
    require(g<1e-5, 'g<1e-5')
    lo,_=sqrt_fraction_bounds(1-Fraction(g));_,hi=sqrt_fraction_bounds(1+Fraction(g))
    norm=fraction_up((hi*Fraction(float(max(abs(vals))))+Fraction(r))/lo)
    minval=float(min(abs(vals)))
    den=Fraction(minval)-Fraction(r)/lo
    inv=fraction_up((hi/lo)/den) if den>0 else float('inf')
    return norm,inv,{'gram_error':g,'eigen_residual':r,'minimum_proposed_abs_eigenvalue':minval,'maximum_proposed_abs_eigenvalue':float(max(abs(vals)))}

def potential_coefficients(base,sin,c,cos,nphi=1024):
    v=evaluate(base,sin,c);v4=v.power(4)*5;v8=v.power(8)*25
    # nphi is a power of two; its reciprocal is exact binary64.
    return v4.mm(cos)*(1/nphi),v8.mm(cos)*(1/nphi)

def base_inverse(w,base,Vhat):
    ids=np.flatnonzero(ML[:,1]<=64);groups=sorted(set(ML[ids,0]));blocks=[];B=Ball(np.zeros((len(ids),len(ids))))
    offsets={};off=0
    for m in groups:
        js=ids[ML[ids,0]==m];offsets[m]=(off,off+len(js),js);off+=len(js)
    for m in groups:
        i0,i1,ix=offsets[m];p=base[:,ix]
        for m2 in groups:
            j0,j1,jx=offsets[m2]
            f=Vhat[:,abs(m-m2)]-Vhat[:,m+m2]
            # pi is enclosed using high-quality exact decimal rational bounds.
            pi_lo,pi_hi=PI_BRACKET
            block=p.T.mm(base[:,jx]*Ball((w*f).m[:,None],(w*f).r[:,None]))
            block=block*Ball.endpoints(pi_lo,pi_hi)
            B.m[i0:i1,j0:j1]=-block.m;B.r[i0:i1,j0:j1]=block.r
    diag=4*ML[ids,1]*(ML[ids,1]+1)+.75
    B=B+np.diag(diag)
    norm,b0,details=finite_spectral_bound(B)
    M=Fraction(673,200);V=5*M**4;lam=Fraction(4*65*66)+Fraction(3,4);tau=lam-V
    b0q=Fraction(b0);s=V*V/tau
    require(b0q*s<1, 'b0q*s<1')
    bs=b0q/(1-b0q*s)
    b=bs*(1+V/tau)**2+1/tau
    out={'finite_inverse_upper':b0,'tail_lower':fraction_down(tau),'tail_exact':str(tau),'Schur_perturbation_upper':float(up(float(s))),'full_inverse_upper':float(up(float(b))),'target':.06,'pass':b<Fraction(3,50),**details}
    log('BASE_INVERSE',out);return out

def load_radial(a,b,jmax,n,folder,manifest):
    key=tuple(sorted((a,b)));fullj=manifest[key]
    arr=load_ball(folder/f'radial_{key[0]}_{key[1]}.bin',(n,fullj+1))[:, :jmax+1]
    if a>b:
        signs=(-1.)**np.arange(jmax+1)
        arr=Ball(arr.m[::-1]*signs,arr.r[::-1])
    return arr

def verify_charge(m,w,Vhat,V2hat,folder,n,manifest):
    N=112 if m in (2,15) else 80
    low=math.ceil((m-N)/2);high=math.floor((m+N)/2)
    reports=[]
    for residue in range(4):
        ls=[l for l in range(low,high+1) if l%4==residue]
        if not ls:continue
        bases=[];diags=[];sizes=[]
        for l in ls:
            a,b=abs(m-l),abs(l);jmax=(N-a-b)//2
            bases.append(load_radial(a,b,jmax,n,folder,manifest))
            ell=a+b+2*np.arange(jmax+1);diags.extend((ell*(ell+2)+.75).tolist());sizes.append(jmax+1)
        offsets=np.cumsum([0]+sizes);dim=int(offsets[-1]);Vp=Ball(np.zeros((dim,dim)));V2p=Ball(np.zeros((dim,dim)))
        for i,p in enumerate(bases):
            sl=slice(offsets[i],offsets[i+1])
            for j in range(i,len(bases)):
                sj=slice(offsets[j],offsets[j+1]);k=abs(ls[i]-ls[j]);fac=w*Vhat[:,k];fac2=w*V2hat[:,k]
                block=p.T.mm(bases[j]*Ball(fac.m[:,None],fac.r[:,None]));block2=p.T.mm(bases[j]*Ball(fac2.m[:,None],fac2.r[:,None]))
                for mat,bl in ((Vp,block),(V2p,block2)):
                    mat.m[sl,sj]=bl.m;mat.r[sl,sj]=bl.r
                    mat.m[sj,sl]=bl.m.T;mat.r[sj,sl]=bl.r.T
        A=Ball(np.diag(diags))-Vp
        vals,U=eigh((A.m+A.m.T)/2,check_finite=False)
        sel=np.abs(vals)<1e-3 if m<=2 else np.zeros(dim,dtype=bool)
        Z=Ball(U[:,sel]);rank=int(sum(sel))
        B=A+(Z.mm(Z.T) if rank else Ball(np.zeros((dim,dim))))
        C=np.linalg.inv(B.m);Cb=Ball(C)
        residual=Ball(np.eye(dim))-B.mm(Cb);d=frob(residual)
        tail=V2p-Vp.mm(Vp);E=Cb.T.mm(tail).mm(Cb)
        a2,_,detail=finite_spectral_bound(E);a=float(sqrt_up(a2))
        M=Fraction(337,100);beta=5*M**4/(Fraction((N+1)*(N+3))+Fraction(3,4))
        eta2=Fraction(d)**2+Fraction(a)**2+2*beta**2
        eta=float(sqrt_up(float(up(float(eta2)))))
        require(Fraction(eta)**2>=eta2, 'Fraction(eta)**2>=eta2')
        tail_inverse=Fraction(1)/(Fraction((N+1)*(N+3))+Fraction(3,4))
        tnorm=max(frob(Cb),fraction_up(tail_inverse))
        rep={'residue':residue,'dimension':dim,'lifted_rank':rank,'finite_residual_upper':d,'low_tail_upper':a,'beta_upper':float(up(float(beta))),'eta_upper':eta,'T_upper':tnorm,'matrix_entry_radius_V':float(np.max(Vp.r)),'matrix_entry_radius_V2':float(np.max(V2p.r)),**detail}
        reports.append(rep)
        log('CHARGE_BLOCK',m,residue,'dim',dim,'rank',rank,'eta',eta,'T',tnorm,'radius',rep['matrix_entry_radius_V2'])
    expected={0:3,1:2,2:1}.get(m,0)
    out={'charge':m,'cutoff':N,'blocks':reports,'lifted_rank':sum(x['lifted_rank'] for x in reports),'eta_upper':max(x['eta_upper'] for x in reports),'T_upper':max(x['T_upper'] for x in reports)}
    out['pass']=out['lifted_rank']==expected and out['eta_upper']<.6 and out['T_upper']<5
    (DATA/f'charge_{m:02}.json').write_text(json.dumps(out,indent=2));return out

def verify_main(charges=None):
    folder,n,w,base,sin=table_values('tables');c96,c64=coeffs();cos=load_ball(folder/'trig.bin',(1024,129))
    if not (DATA/'potential64.npz').exists():
        vh,v2h=potential_coefficients(base,sin,c64,cos)
        np.savez(DATA/'potential64.npz',m=vh.m,r=vh.r,m2=v2h.m,r2=v2h.r)
    else:
        a=np.load(DATA/'potential64.npz');vh,v2h=Ball(a['m'],a['r']),Ball(a['m2'],a['r2'])
    if charges is None:
        v96,_=potential_coefficients(base,sin,c96,cos)
        b=base_inverse(w,base,v96);(DATA/'base_inverse.json').write_text(json.dumps(b,indent=2))
        charges=range(26)
    manifest={tuple(row[:2]):row[2] for row in json.loads((folder/'manifest.json').read_text())['pairs']}
    for m in charges:
        t=time.time();out=verify_charge(m,w,vh,v2h,folder,n,manifest);log('CHARGE_DONE',m,out['pass'],'seconds',time.time()-t)
        if not out['pass']:raise RuntimeError(f'certificate failed for charge {m}')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['tables','residual','grid','check_residual','check_grid','check_main']);ap.add_argument('--charges')
    args=ap.parse_args()
    if args.stage in ('tables','residual','grid'):generate(args.stage)
    elif args.stage=='check_residual':
        r=verify_residual();(DATA/'residual.json').write_text(json.dumps(r,indent=2));require(r['pass'], "r['pass']")
    elif args.stage=='check_grid':
        r=verify_sup_bridge();(DATA/'sup_bridge.json').write_text(json.dumps(r,indent=2));require(r['pass'], "r['pass']")
    else:verify_main(None if args.charges is None else [int(x) for x in args.charges.split(',')])
