A Counterexample to Fixed-Profile Soliton Resolution
for the Three-Dimensional Quintic Wave Equation
Standalone manuscript and complete reproducibility package
13 November 2026

SCOPE AND STRUCTURE
The paper is supplied as ONE self-contained TeX file. Its preamble, proofs,
TikZ figures, tables, AI disclosure and bibliography are all included. There
is no parts directory and no external TeX, bibliography or image input.
The numerical certification files are supplementary and are not needed to
compile the manuscript.

The revised manuscript has 54 pages, with unchanged font size and margins.
Section 1.2 now gives the idea of the proof in four steps. Figure 1.1 connects
the stationary geometry and force estimates to the global construction and
then to the two-step contradiction. Table 1.1 explains the role of each
section. The stationary certificate is in Appendix A. Principal notation is
collected on one page in Appendix B. The final page contains the AI disclosure
and bibliography. The earlier geometric and paired-impulse diagrams remain.

The uploaded five-dimensional paper is cited as:
X. Chen, J. Holmer and S. Shen, Radiation and persistent shape dynamics for
the five-dimensional energy-critical nonlinear wave equation, manuscript,
2026. Its reference contains no arXiv identifier or submission information.
The organization follows that supplied manuscript; the expository prose also
draws on the requested Chen--Holmer Inventiones 2019 paper without copying
its wording. Narrative colons have been reduced and grammatical subjects
made explicit throughout the proofs.

FURTHER PROOF SIMPLIFICATION
Section 8 writes the endpoint coordinate as a double integral of the
coordinate acceleration B = Phi(Delta U + U^5). The exact primitive identity
shows that this is equivalent to the preceding endpoint map, with the same
two correction coefficients. The integral formulation simplifies continuity
in the uniform path topology. At the fixed point the correction vanishes,
so the coordinate equation follows directly. Matching values and first
derivatives rule out endpoint atoms; adding the projected equation recovers
the original NLW.

The H1 path domain from the preceding revision is retained. Its prescribed
endpoints and block L2 derivative bounds imply the position bound, a common
one-half Holder modulus and C0 compactness. No pointwise derivative constraint
is imposed. The regularity needed for the H1--H^{-1} product rule is stated
before the calculation that uses it.

The fixed-profile contradiction still uses one positive Hilbert norm identity
to identify the free radiation and force a single nonzero profile. The second
core limit then contradicts the stationary similarity separation. The proof
guide explains why two limits suffice for the fixed-list conclusion, without
claiming the continuum conclusion of the five-dimensional manuscript.

AI DISCLOSURE
The supplied words are retained except for three grammatical corrections:
    that whether radiation -> that radiation
    found that, the -> found that the
    does not not apply -> does not apply
The [5D] placeholders become citations to the same reference. No additional
sentence has been appended. revision_checks.json records the exact normalized
comparison with the user's paragraph after these corrections.

FILES
recurrent_shape_dynamics.tex
    The ONLY TeX file in the archive; compile it directly.
check_manuscript.py and source_checks.txt
    Checks self-containment, labels, references, citations and equation labels.
proof_checks.py and proof_checks.json
    Standard-library exact algebra/exponent checks. All 62 checks pass,
    including 16 added polynomial checks of the integral coordinate map.
    The saved report records byte comparison of all 45 certification files.
revision_checks.json
    Records exact disclosure, source structure and figure/provenance checks.
REVISION_NOTES.txt
    Chinese account of the edits, adopted proof simplification, and considered
    alternatives that would require additional estimates.
PROOF_GUIDE_CHANGES.patch
    Changes relative to the preceding standalone 51-page edition.
certification/
    Unchanged exact inputs, verifier, executed reports and full numerical log.
SHA256SUMS.txt
    Checksums for every distributed file except the manifest itself.

BUILD
Use a TeX Live installation with XeLaTeX and the standard packages listed
in the preamble. No Chinese fonts are required.

From this directory:
    python3 check_manuscript.py
    xelatex -interaction=nonstopmode -halt-on-error recurrent_shape_dynamics.tex
    xelatex -interaction=nonstopmode -halt-on-error recurrent_shape_dynamics.tex
Run XeLaTeX again if it requests a reference or table-width rerun.
No source assembly, BibTeX or external figures are needed.

To repeat the exact proof checks:
    python3 proof_checks.py
To include a byte comparison against a previous source tree:
    python3 proof_checks.py --certificate-baseline PREVIOUS_SOURCE_ROOT
These are exact algebra and exponent checks, with finitely many polynomial
examples for the new integral map. They do not replace the analytic proofs
in the paper and are not a proof-assistant verification of the manuscript.

REPRODUCE THE CERTIFICATE
Requirements: Linux x86-64; Python 3 with NumPy and SciPy; g++; GMP headers
and library; and the MPFR 4.x runtime library libmpfr.so.6.
The successful recorded run used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0,
GCC 14.2.0 and MPFR 4.2.2.

The arithmetic model is IEEE binary64, round-to-nearest, and long double
with at least 64 significand bits and the exponent range of the recorded
x86-64 platform. Fast-math and floating-point contraction are disabled.
The minimal MPFR declarations in the backend target the standard Linux/GMP
ABI used in that run. Adapt them to the official platform MPFR header before
using a different ABI; then rerun every verification stage.

In certification/ run:
    python3 run_fresh.py

The runner rebuilds backend.so and creates a new, uniquely named directory
under runs/. It generates all quadrature and basis tables, verifies the full
residual, supremum and truncation error, certifies the full base inverse,
checks every charge block, and evaluates the final inequalities using exact
fractions. It writes latest_run.txt only when every stage passes.
The runner also performs the supplementary implementation checks and release
regressions. They can be repeated after a successful run with:
    python3 audit_checks.py
    python3 regression_checks.py

Every numerical entry point explicitly rejects Python -O, -OO, and an
effective PYTHONOPTIMIZE setting before reading certificate data. The runner
also removes PYTHONOPTIMIZE from its child environment. All acceptance checks
use explicit exceptions; none depends on Python assert. The regression suite
checks a valid report set, 35 rejected optimization/corruption cases, and
exact rational lower rounding. Its negative controls corrupt temporary report
copies only.

reports/verification.log contains the preceding audit revision's execution, including the
compiler invocation, numerical stages, rational aggregation, supplementary
checks and negative controls. reports/environment.json records its SHA-256.
The recorded run freshly executed the audit-revised verifier. The verifier
and exact input are unchanged in this proof-guide revision; no new
full numerical run is claimed here. The JSON tail_lower is a downward-rounded
binary64 enclosure; tail_exact retains the exact rational value.

The last line of the full certificate run should be:
    ALL CHECKS PASSED

The run requires several minutes and a few hundred MB of temporary storage,
depending on the machine. Tables and proposals are recomputed rather than
accepted from the reports included in this archive. Approximate eigensolvers
and inverses only propose matrices; the verification code bounds their
residuals and orthogonality defects independently of those proposals.

Compiler invocation, performed automatically by the runner:
    g++ -O2 -std=c++17 -shared -fPIC -fopenmp -fno-fast-math -ffp-contract=off interval_backend.cpp -Wl,-l:libmpfr.so.6 -lgmp -o backend.so

CERTIFIED ACCEPTANCE BUDGETS
Full residual:                 less than 2e-7
Candidate supremum:           less than 673/200
Full base inverse norm:        less than 3/50
H2_* stationary error:        at most 1/100000
Spectral-candidate error:      at most 1/500000
Low-charge blocks:            104, covering charges 0 through 25
Negative charges:             covered by complex conjugation
High-charge positivity:       637082239/20000000, for |m| >= 26
Total complex rank columns:   9
Parametrix error budget:       3/5
Parametrix norm budget:        5
Perturbed error budget:        3038272753/5000000000
Strict positive margin:       1961727247/5000000000 = 0.3923454494

These displayed budgets are exact rational numbers. The reports contain
stronger computed bounds. All omitted harmonics are covered by the tail
estimates proved in the paper. The full spherical dimension nine is combined
with conformal geometry and the involution action to obtain odd dimension
four; four approximate eigenvectors alone would not prove exhaustion.


PROVENANCE
This edition revises the three-dimensional manuscript supplied in the current
conversation after the earlier audits and proof reviews. The preceding
51-page PDF was checked against the latest uploaded three-dimensional PDF.
The five-dimensional citation and proof-guide structure are grounded in the
uploaded five-dimensional manuscript. No journal publication details have
been invented for that paper. Author names on the three-dimensional title
page have not been inferred from the reference manuscript.
