"""Check the standalone manuscript, references, citations and selective numbering."""
from pathlib import Path
import re
from collections import Counter
root=Path(__file__).resolve().parent
text=(root/'recurrent_shape_dynamics.tex').read_text()
if re.search(r'\\(?:input|include|bibliography|includegraphics)\b',text):
    raise RuntimeError('The manuscript must be self-contained')
labels=re.findall(r'\\label\{([^}]+)\}',text)
refs=re.findall(r'\\(?:eqref|ref|pageref)\{([^}]+)\}',text)
cites=[k.strip() for g in re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}',text) for k in g.split(',')]
bib=re.findall(r'\\bibitem\{([^}]+)\}',text)
dup=sorted(k for k,n in Counter(labels).items() if n>1)
missing=sorted(set(refs)-set(labels));missing_cites=sorted(set(cites)-set(bib))
display_pattern = re.compile(
    r'\\begin\{(?P<env>equation|align|gather|multline)(?P<star>\*?)\}'
    r'(?P<body>.*?)\\end\{(?P=env)(?P=star)\}', re.S)
equation_labels = set()
labels_in_unnumbered = []
numbered_without_label = []
numbered_count = unnumbered_count = 0
for match in display_pattern.finditer(text):
    local_labels = re.findall(r'\\label\{([^}]+)\}', match['body'])
    equation_labels.update(local_labels)
    if match['star']:
        unnumbered_count += 1
        labels_in_unnumbered.extend(local_labels)
    else:
        numbered_count += 1
        if not local_labels:
            numbered_without_label.append(text[:match.start()].count('\n') + 1)
for match in re.finditer(r'(?<!\\)\\\[(.*?)(?<!\\)\\\]', text, re.S):
    unnumbered_count += 1
    labels_in_unnumbered.extend(re.findall(r'\\label\{([^}]+)\}', match[1]))
equation_refs = set(re.findall(r'\\eqref\{([^}]+)\}', text))
non_equation_eqrefs = sorted(equation_refs - equation_labels)
plain_equation_refs = sorted(equation_labels.intersection(re.findall(r'\\ref\{([^}]+)\}', text)))
unused_equation_labels = sorted(equation_labels - set(refs))
fraction_errors = []
for match in re.finditer(r'\\(?:tfrac|dfrac|frac)(?![A-Za-z])', text):
    p = match.end()
    if match[0] != r'\frac':
        fraction_errors.append(text[:match.start()].count('\n') + 1)
        continue
    for _ in range(2):
        while p < len(text) and text[p].isspace(): p += 1
        if p == len(text) or text[p] != '{':
            fraction_errors.append(text[:match.start()].count('\n') + 1)
            break
        depth = 1
        p += 1
        while p < len(text) and depth:
            if text[p] == '{' and text[p-1] != '\\': depth += 1
            elif text[p] == '}' and text[p-1] != '\\': depth -= 1
            p += 1
report=(
    f'Source lines: {len(text.splitlines())}\n'
    f'Labels: {len(labels)}\n'
    f'Numbered display environments: {numbered_count}\n'
    f'Unnumbered display environments: {unnumbered_count}\n'
    f'Duplicate labels: {dup}\nMissing references: {missing}\n'
    f'Missing citations: {missing_cites}\n'
    f'Labels in unnumbered displays: {labels_in_unnumbered}\n'
    f'Numbered displays without labels: {numbered_without_label}\n'
    f'Equation references to non-equations: {non_equation_eqrefs}\n'
    f'Plain references to equations: {plain_equation_refs}\n'
    f'Unused equation labels: {unused_equation_labels}\n'
    f'Nonstandard fraction commands (source lines): {fraction_errors}\n')
(root/'source_checks.txt').write_text(report);print(report)
if any((dup, missing, missing_cites, labels_in_unnumbered,
        numbered_without_label, non_equation_eqrefs,
        plain_equation_refs, unused_equation_labels, fraction_errors)):
    raise RuntimeError("Standalone manuscript checks failed; see source_checks.txt")
