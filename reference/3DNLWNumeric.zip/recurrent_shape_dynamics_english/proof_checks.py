"""Exact checks of algebra, exponents and the integral coordinate map; not a proof audit.

Uses only Python's standard library. An optional --certificate-baseline points
to a previous source root for byte comparison of the distributed certificate.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json

checks = []


def check(name, condition, **detail):
    if not condition:
        raise RuntimeError(name)
    checks.append({'name': name, 'passed': True, **detail})


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scale(c, a):
    return tuple(c * x for x in a)


# Coefficients of formal normalized variables (I_0/eta^2, I_1/d,
# integral Z/d, Delta gamma/d). No choice of numerical source is made.
u = (F(1), F(0), F(0), F(0))
v = (F(0), F(1), F(-1), F(-1))
c1 = add(v, scale(-1, u))
c2 = add(scale(2, u), scale(-1, v))
check('fixed moment inverse: first row', add(c1, c2) == u)
check('fixed moment inverse: second row', add(scale(2, c1), c2) == v)
check('terminal momentum residual is zero', add(u, scale(-1, add(c1, c2))) == (0,)*4)
check('terminal chart-coordinate residual is zero', add(v, scale(-1, add(scale(2, c1), c2))) == (0,)*4)
check('maximum-norm bound for L inverse', max(1+1, 2+1) == 3)
for start in (F(0), F(1)):
    for center, moment in ((F(2), F(2)), (F(3), F(1))):
        check(f'bump support and first moment: start={start}, center={center}',
              start < center-F(1, 4) and center+F(1, 4) < 4 and 4-center == moment,
              integral_h_over_T=str(moment), basis='unit mass and zero centered first moment')

# Formal coefficients in (integral k, alpha_end, alpha_start,
# Delta theta, Delta Phi R): -integral Z - Delta gamma.
minus_z = (1, 1, -1, 0, 0)
delta_gamma = (0, 1, -1, 1, 1)
check('alpha endpoint differences cancel',
      add(minus_z, scale(-1, delta_gamma)) == (1, 0, 0, -1, -1))
for a in ((1, 0), (0, 1)):
    mapped = (a[0]+a[1], 2*a[0]+a[1])
    recovered = (mapped[1]-mapped[0], 2*mapped[0]-mapped[1])
    check(f'control update cancels input displacement {a}', recovered == a)
# Coefficients of (H, (b alpha) prime, B).
pi_prime = (1, -1, 0)
z_prime = (1, -1, -1)
check('recovered coordinate acceleration is B',
      add(pi_prime, scale(-1, z_prime)) == (0, 0, 1))

for p in (2, 3):
    inv_coefficient = F(17-5*p, 30)
    coefficient_decay = 2*(5-p)-1
    check(f'localized derivative Holder, degree {p}',
          inv_coefficient + F(p-1, 6) + F(1, 2) == F(9, 10)
          and coefficient_decay/inv_coefficient > 3,
          coefficient_Lp=str(1/inv_coefficient))
check('quartic derivative space Holder', F(1, 15)+F(3, 9)+F(1, 2) == F(9, 10))
check('quartic derivative time Holder', F(3, 6) == F(1, 2))
check('quartic L6 L9 interpolation', F(5, 6)/5 == F(1, 6)
      and F(1, 6)/6 + F(5, 6)/10 == F(1, 9))
for theta, qt, px in ((F(0), F(5), F(10)), (F(1, 5), F(25, 4), F(50, 9)),
                       (F(1, 4), F(20, 3), F(5)), (F(1, 16), F(16, 3), F(8))):
    check(f'mass-Strichartz interpolation theta={theta}',
          1/qt == (1-theta)/5 and 1/px == theta/2+(1-theta)/10,
          time_exponent=str(qt), space_exponent=str(px))
    check(f'halo time integrability at ({qt},{px})', px > 3 and qt*(1-3/px) > 1,
          integrability_power=str(qt*(1-3/px)))
for qt, px, out_t, out_x in ((F(5), F(10), F(1), F(2)),
                             (F(25, 4), F(50, 9), F(5, 4), F(10, 9)),
                             (F(20, 3), F(5), F(4, 3), F(1))):
    check(f'pure quintic zero order into ({out_t},{out_x})', 5/qt == 1/out_t and 5/px == 1/out_x)
check('pure quintic gradient into L5/4 L10/9', F(4, 5) == 1/F(5, 4)
      and F(4, 10)+F(1, 2) == F(9, 10))
check('pure quintic gradient into L4/3 L1', 4/F(16, 3) == F(3, 4)
      and F(4, 8)+F(1, 2) == 1)

check('block scales T_j eta_j^2=d', -5+2*3 == 1 and 2-2 == 0)
check('old-response normalized observation scale', 4-F(1, 2)+F(5, 4) == F(19, 4))
check('quadratic old-force normalized scale', 2*4-F(1, 2)+F(5, 12) == F(95, 12))
check('quintic old-source normalized scale', 5*4-F(1, 2) == F(39, 2))
for p in (3, 4, 5):
    power = 4*p-1+5*(F(11-p, 6)-1)
    check(f'pure old force normalized degree {p}', power == F(19*(p+1), 6) and power > F(1, 2),
          power_of_d=str(power))

# Exact tests of piecewise linear admissible paths, including the exceptional
# first interval. Compactness and the H1 product rule are proved in the text.
for d in (F(1,10), F(1,100)):
    for count in (1,2,4,8):
        eps = d**3
        previous_end = F(0)
        total_derivative_squared = F(0)
        ratios = []
        valid = True
        for j in range(count):
            T = 4**j/d**5
            eta = eps/2**j
            start = F(0) if j == 0 else T
            end = 4*T
            length = end-start
            theta_start, theta_end = d*(j%2), d*((j+1)%2)
            slope = (theta_end-theta_start)/length
            derivative_squared = slope**2*length
            ratio = derivative_squared/(d*eta**2)
            valid &= start == previous_end and T*eta**2 == d
            valid &= slope*length == theta_end-theta_start
            valid &= ratio <= F(1,3)
            valid &= max(theta_start,theta_end) <= d
            ratios.append(str(ratio))
            total_derivative_squared += derivative_squared
            previous_end = end
        valid &= total_derivative_squared <= F(4,3)*d*eps**2
        check(f'H1 interpolation path: d={d}, intervals={count}', valid,
              block_squared_norm_ratios=ratios,
              global_squared_norm_over_d_eps2=str(total_derivative_squared/(d*eps**2)))

# Compare the old integrated-force map with the twice-integrated coordinate
# equation on polynomial bases. These exact examples check signs, constants
# and both bump terms. The general identity is Fubini's theorem in the paper.
def polynomial(values):
    values = list(map(F, values))
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    return tuple(values)


def poly_add(*terms):
    out = [F(0)] * max(map(len, terms))
    for term in terms:
        for i, value in enumerate(term):
            out[i] += value
    return polynomial(out)


def poly_scale(c, term):
    return polynomial(c*x for x in term)


def primitive(term):
    return polynomial([0] + [x/F(i+1) for i, x in enumerate(term)])


def derivative(term):
    return polynomial([F(i)*x for i, x in enumerate(term) if i] or [0])


for length in (F(3), F(4)):
    h1 = polynomial([0, 0, 3/length**2, -2/length**3])
    h2 = polynomial([0, 0, 0, 1/length**3])
    correction = poly_add(poly_scale(F(2, 5), h1), poly_scale(F(-3, 7), h2))
    for source in ('B', 'Z'):
        for degree in range(4):
            basis = polynomial([0]*degree + [1])
            B = basis if source == 'B' else polynomial([0])
            Z = basis if source == 'Z' else polynomial([0])
            force = poly_add(derivative(Z), B)
            momentum = poly_add(primitive(force), poly_scale(F(-1, 10), correction))
            old_map = poly_add(polynomial([F(2, 7)]), primitive(poly_add(momentum, poly_scale(-1, Z))))
            new_map = poly_add(polynomial([F(2, 7), -Z[0]]), primitive(primitive(B)),
                               poly_scale(F(-1, 10), primitive(correction)))
            acceleration = poly_add(B, poly_scale(F(-1, 10), derivative(correction)))
            check(f'integral coordinate map: length={length}, source={source}, degree={degree}',
                  old_map == new_map
                  and derivative(new_map) == poly_add(momentum, poly_scale(-1, Z))
                  and derivative(derivative(new_map)) == acceleration)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--certificate-baseline', type=Path)
args = parser.parse_args()
report = {'status': 'passed', 'scope': __doc__.splitlines()[0], 'checks': checks}
if args.certificate_baseline is not None:
    root = Path(__file__).resolve().parent
    patterns = ('certification/*.py', 'certification/*.cpp', 'certification/inputs/*.json',
                'certification/inputs/*.hex', 'certification/reports/*.json',
                'certification/reports/verification.log')
    paths = sorted({p.relative_to(root).as_posix() for pat in patterns for p in root.glob(pat)})
    old_paths = sorted({p.relative_to(args.certificate_baseline).as_posix() for pat in patterns
                        for p in args.certificate_baseline.glob(pat)})
    if paths != old_paths:
        raise RuntimeError('certificate file set changed')
    manifest = []
    for name in paths:
        data = (root/name).read_bytes()
        if data != (args.certificate_baseline/name).read_bytes():
            raise RuntimeError(f'certificate changed: {name}')
        manifest.append({'file': name, 'sha256': hashlib.sha256(data).hexdigest()})
    env = json.loads((root/'certification/reports/environment.json').read_text())
    log_hash = hashlib.sha256((root/'certification/reports/verification.log').read_bytes()).hexdigest()
    if log_hash != env['log_sha256']:
        raise RuntimeError('recorded numerical run log hash mismatch')
    report['certificate_comparison'] = {'status': 'byte-identical', 'file_count': len(paths),
        'numerical_rerun_performed': False, 'recorded_log_sha256': log_hash, 'files': manifest}
Path(__file__).with_name('proof_checks.json').write_text(json.dumps(report, indent=2)+'\n')
print(f'{len(checks)} exact algebra/exponent checks passed')
if 'certificate_comparison' in report:
    print(f'{len(paths)} certificate files are byte-identical; recorded log hash matches')
