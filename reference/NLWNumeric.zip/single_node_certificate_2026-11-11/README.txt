FIVE-DIMENSIONAL SINGLE-NODE SPECTRAL CERTIFICATE
11 November 2026

This package accompanies Appendix C of wave_shape_dynamics_abstract.tex.
It proves strict shooting and matching-determinant signs for the k=3
symmetric single-node profile studied in Neves--Pistoia,
arXiv:2610.40960v1. The complete analytical implication to a full
15-dimensional conformal kernel is in the manuscript and audit report.

RESULT
For an exact midpoint-zero profile with
  5.234683 < A < 5.234684,
the certified determinant signs imply, with the analytical Sturm argument,
  4 < alpha_* < 5, equivalently 20 < Lambda_* < 30.

Safe exact-decimal statement bounds:
  lower-amplitude midpoint: [1.4770,1.5151] * 10^(-7);
  upper-amplitude midpoint: [-3.0775,-3.0394] * 10^(-7);
  D4 over the whole amplitude interval: [-7.328,-7.327];
  D5 over the whole amplitude interval: [75.683,75.685].
The printed 17-digit output endpoints round-trip to binary64; they are
not outward decimal serialization. Use the widened bounds above in prose.
Every reported successful run must exit with code 0.

FILES
  single_node_certificate.cpp
      Final readable guarded source. No external library is needed for
      the normal build. EXACT_RATIONAL_AUDIT enables optional GMP checks
      in the identical mathematical implementation.
  small_t_initialization_certificate.txt
      Analytical proof of the origin enclosures. The optional sharper
      second-order bounds in this note are not used by this executable.
  profile_lower.txt, profile_upper.txt, mode_determinants.txt
      Independently rerun final normal outputs; matching .log files.
  exact_validation/
      Final same-source GMP outputs and logs from the fresh audit.
  validation/
      Rejected-invalid-input and floating-environment test records.
  reproduce.sh
      Builds and runs all three required cases in a new build/ directory.
  SHA256SUMS
      Digests of the released source, records and instructions.

REPRODUCTION
Tested with g++ (Debian 14.2.0-19) 14.2.0 on x86_64 Linux, binary64
round-to-nearest with gradual underflow. The source uses GNU unsigned
__int128 for exact decimal and grid comparisons. It rejects unsupported
floating environments and unsafe fast-math builds.

Normal build:
  g++ -O2 -std=c++17 -fno-fast-math -ffp-contract=off -frounding-math \
    single_node_certificate.cpp -o certificate

Required calls:
  ./certificate 5.234683 5.234683 2 0.0002
  ./certificate 5.234684 5.234684 2 0.0002
  ./certificate 5.234683 5.234684 10 0.0002

Optional exact-rational audit (GMP C++ development library required):
  g++ -O2 -std=c++17 -fno-fast-math -ffp-contract=off -frounding-math \
    -DEXACT_RATIONAL_AUDIT single_node_certificate.cpp \
    -lgmpxx -lgmp -o certificate_exact
Run the same three argument lists with ./certificate_exact.

Or run:
  bash reproduce.sh
  bash reproduce.sh exact

All three normal and all three exact-audit outputs agree byte for byte.
Each run takes 7,646 accepted steps. The exact-audit counters exclude
determinant operations printed after integration, but those operations
are also checked against exact rational arithmetic.

SOURCE IDENTITY
SHA-256 of single_node_certificate.cpp:
bf817f4c17e307fde93a0bd544ed5a54e0d79348ae5e26bba2e87560473f99ee

The source was released under the filename above without modifying its
bytes. Its header uses the development filename certificate_guarded.cpp;
substitute single_node_certificate.cpp when following that header's
example build command. The commands in this README already do so.

MATHEMATICAL AND COMPUTATIONAL SCOPE
The three runs establish existence of at least one exact positive
half-profile by continuity and monotonicity, and uniform determinant
signs for every amplitude in the bracket. Uniqueness of the shooting
root is not a numerical conclusion. The ordinary differential equations,
regular endpoint conditions, Sturm ordering, radial exclusion and
conformal transfer must be read with the analytical proof.

The code is a specialized certificate, not a generic validated ODE solver.
Strict runtime guards were added during this audit; the mathematical
formulas and successful output enclosures were unchanged. All primitive
arithmetic checks, interval tubes, remainder bounds and comparison
inequalities were audited. This remains a conventional computer-assisted
proof relying on compiler/runtime/hardware, not proof-assistant-certified
software.
