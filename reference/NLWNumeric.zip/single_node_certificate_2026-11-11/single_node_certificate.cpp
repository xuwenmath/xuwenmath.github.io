// Validated k=3 shooting and mode-sign certificate, guarded audit copy.
// Original arithmetic and mathematical formulas are unchanged.
// Build: g++ -O2 -std=c++17 -fno-fast-math -ffp-contract=off -frounding-math certificate_guarded.cpp -o certificate
// Exact audit: add -DEXACT_RATIONAL_AUDIT and link -lgmpxx -lgmp.
// Intended calls: 5.234683 5.234683 2 0.0002; 5.234684 5.234684 2 0.0002;
//                 5.234683 5.234684 10 0.0002.
// Initialization proof: small_t_initialization_certificate.txt.
// Printed decimal endpoints round to nearest; sign assertions are on binary endpoints.
// For exact endpoint serialization use the corresponding binary64 values (17 digits round-trip).
#include <cmath>
#include <algorithm>
#include <iostream>
#include <vector>
#include <iomanip>
#include <stdexcept>
#include <cfenv>
#include <limits>
#include <cfloat>
#include <cstdint>
#include <cstring>
#include <string>
#ifdef EXACT_RATIONAL_AUDIT
#include <gmpxx.h>
#endif
#ifdef __FAST_MATH__
#error "Fast-math is incompatible with this certificate"
#endif
using namespace std;
using U128 = unsigned __int128;
uint64_t add_checks = 0, mul_checks = 0, recip_checks = 0, grid_checks = 0;
void req(bool ok, const char * message) {
    if (!ok) throw runtime_error(message);
}

struct Decimal {
    uint64_t num, den;
};

Decimal decimal(const string & s) {
    req(!s.empty(), "empty decimal");
    uint64_t n = 0, d = 1;
    bool dot = false, any = false;
    int places = 0;
    for (char c : s) {
        if (c == '.') {
            req(!dot, "multiple decimal points");
            dot = true;
            continue;
        }
        req(c >= '0' && c <= '9', "amplitudes must be unsigned ordinary decimals");
        any = true;
        req(n <= 1000000000000ULL, "decimal numerator too large");
        n = n * 10 + unsigned(c - '0');
        if (dot) {
            req(++places <= 12, "too many decimal places");
            d *= 10;
        }
    }
    req(any && n <= 10000000000000ULL, "invalid decimal");
    return {
        n, d
    };
}

int cmp(Decimal a, Decimal b) {
    U128 l = U128(a.num) * b.den, r = U128(b.num) * a.den;
    return (l > r) - (l < r);
}

struct Dyadic {
    uint64_t m;
    int e;
};

Dyadic dyadic(double x) {
    req(isfinite(x) && x > 0, "positive finite dyadic required");
    uint64_t bits;
    memcpy(& bits, & x, sizeof bits);
    unsigned exponent = (bits >> 52) & 2047U;
    req(!(bits >> 63) && exponent > 0 && exponent < 2047, "normal positive binary64 required");
    return {
        (bits & 0xfffffffffffffULL) | (1ULL << 52), int(exponent) - 1075
    };
}

int cmp(double x, Decimal q) {
    auto z = dyadic(x);
    req(z.e <= 0 && z.e >= - 80, "decimal comparison range");
    U128 l = U128(z.m) * q.den, r = U128(q.num) << (- z.e);
    return (l > r) - (l < r);
}

U128 grid_units(double x) {
    auto z = dyadic(x);
    req(x <= 1 && z.e >= - 125, "grid lattice range");
    return U128(z.m) << (z.e + 125);
}

void grid_check(double t, double next_t, double h) {
    req(next_t > t && next_t <= 1 && h > 0 && isfinite(h), "nonadvancing or out-of-domain grid");
    req(grid_units(next_t) == grid_units(t) + grid_units(h), "grid difference not exact");
    ++grid_checks;
}

void arithmetic_environment() {
    req(sizeof(double) == 8 && numeric_limits<double>::is_iec559 && numeric_limits<double>::radix == 2 && numeric_limits<double>::digits == 53 && FLT_EVAL_METHOD == 0, "unsupported floating-point environment");
    double one = 1;
    uint64_t bits;
    memcpy(& bits, & one, sizeof bits);
    req(bits == 0x3ff0000000000000ULL, "unsupported binary64 representation");
    req(fesetround(FE_TONEAREST) == 0 && fegetround() == FE_TONEAREST, "round-to-nearest unavailable");
    // Reject flush-to-zero and denormals-are-zero execution modes.
    volatile double sub = numeric_limits<double>::denorm_min();
    double twice = sub + sub;
    uint64_t twice_bits;
    memcpy(&twice_bits, &twice, sizeof twice_bits);
    req(twice_bits == 2, "gradual underflow / subnormal inputs unavailable");
    feclearexcept(FE_ALL_EXCEPT);
}

#ifdef EXACT_RATIONAL_AUDIT
mpq_class Q(double x) {
    req(isfinite(x), "nonfinite rational input");
    return mpq_class(x);
}

void qa(double al, double au, double bl, double bu, double l, double u) {
    ++add_checks;
    req(Q(l) <= Q(al) + Q(bl) && Q(u) >= Q(au) + Q(bu), "addition does not enclose exact result");
}

void qm(double al, double au, double bl, double bu, double l, double u) {
    ++mul_checks;
    mpq_class lo = Q(l), hi = Q(u);
    for (double a : {
        al, au
    }) for (double b : {
        bl, bu
    }) {
        mpq_class z = Q(a) * Q(b);
        req(lo <= z && z <= hi, "multiplication does not enclose exact result");
    }
}

void qr(double bl, double bu, double l, double u) {
    ++recip_checks;
    req(Q(l) <= 1 / Q(bu) && Q(u) >= 1 / Q(bl), "reciprocal does not enclose exact result");
}

#else
void qa(double, double, double, double, double, double) {
}

void qm(double, double, double, double, double, double) {
}

void qr(double, double, double, double) {
}

#endif
// Outward-rounded scalar interval arithmetic.
double dn(double x) {
    return nextafter(x, - INFINITY);
}

double up(double x) {
    return nextafter(x, INFINITY);
}

struct I {
    double l, u;
    I(double x = 0) : l(x), u(x) {
        req(isfinite(x), "nonfinite point");
    }
    I(double a, double b) : l(a), u(b) {
        req(isfinite(a) && isfinite(b) && a <= b, "nonfinite or reversed interval");
    }
};

I operator + (I a, I b) {
    I c(dn(a.l + b.l), up(a.u + b.u));
    qa(a.l, a.u, b.l, b.u, c.l, c.u);
    return c;
}

I operator - (I a) {
    return I(- a.u, - a.l);
}

I operator - (I a, I b) {
    return a + (- b);
}

I operator * (I a, I b) {
    double p[] = { a.l * b.l, a.l * b.u, a.u * b.l, a.u * b.u};
    I c(dn(* min_element(p, p + 4)), up(* max_element(p, p + 4)));
    qm(a.l, a.u, b.l, b.u, c.l, c.u);
    return c;
}

I operator / (I a, I b) {
    if (b.l <= 0 && b.u >= 0) throw runtime_error("zero divisor");
    I c(dn(1 / b.u), up(1 / b.l));
    qr(b.l, b.u, c.l, c.u);
    return a * c;
}

double mag(I a) {
    return max(abs(a.l), abs(a.u));
}

double mid(I a) {
    return a.l + (a.u - a.l) / 2;
}

I cb(I x) {
    if (x.l < 0) throw runtime_error("negative cuberoot");
    double l = cbrt(x.l), u = cbrt(x.u);
    while (x.l > 0 && (I(l) * I(l) * I(l)).u > x.l) l = dn(l);
    while (x.u > 0 && (I(u) * I(u) * I(u)).l < x.u) u = up(u);
    return I(l, u);
}

I ab(I a) {
    return I(a.l <= 0 && a.u >= 0 ? 0 : min(abs(a.l), abs(a.u)), mag(a));
}

// Truncated Taylor jets: coefficient k represents the kth derivative / k!.
using P = vector<I>;
P add(P a, P b) {
    P c(a.size());
    for (int i = 0; i < c.size(); i++) c[i] = a[i] + b[i];
    return c;
}

P neg(P a) {
    for (auto & x : a) x = - x;
    return a;
}

P mul(P a, P b) {
    P c(a.size());
    for (int i = 0; i < c.size(); i++) for (int j = 0; j <= i; j++) c[i] = c[i] + a[j] * b[i - j];
    return c;
}

P scale(P a, I s) {
    for (auto & x : a) x = x * s;
    return a;
}

P con(I a, int n) {
    P p(n);
    p[0] = a;
    return p;
}

P inv(P a) {
    P c(a.size());
    c[0] = I(1) / a[0];
    for (int i = 1; i < c.size(); i++) {
        I s;
        for (int j = 1; j <= i; j++) s = s + a[j] * c[i - j];
        c[i] = - s / a[0];
    }
    return c;
}

P cube(P a) {
    P c(a.size());
    c[0] = cb(a[0]);
    for (int n = 1; n < c.size(); n++) {
        I s;
        for (int i = 0; i <= n; i++) for (int j = 0; j <= n - i; j++) {
            int k = n - i - j;
            if (i == n || j == n || k == n) continue;
            s = s + c[i] * c[j] * c[k];
        }
        c[n] = (a[n] - s) / (I(3) * c[0] * c[0]);
    }
    return c;
}

// Evaluate the differential equations on Taylor jets.
vector<P> rhs(P t, vector<P> z) {
    int n = t.size(), N = z.size();
    P one = con(I(1), n), two = con(I(2), n), di = inv(mul(t, add(two, neg(t))));
    P cbr = cube(z[0]);
    P f = scale(add(mul(mul(z[0], z[0]), cbr), neg(z[0])), I(15) / I(16));
    P V = add(scale(mul(z[0], cbr), I(35) / I(16)), con(- I(15) / I(16), n));
    vector<P> r(N, P(n));
    r[0] = z[1];
    P b = mul(scale(add(one, neg(t)), I(3)), di);
    r[1] = neg(add(mul(b, z[1]), mul(f, di)));
    for (int j = 2; j < N; j += 2) {
        int alpha = j < 6 ? 4 : 5;
        bool L = (j == 2 || j == 6);
        P bb = mul(add(con(I(L ? 3 + 2 * alpha : 3), n), scale(t, I(- (3 + alpha)))), di);
        P q = mul(add(V, con(- I(alpha * (alpha + 4)) / I(4), n)), di);
        r[j] = z[j + 1];
        r[j + 1] = neg(add(mul(bb, z[j + 1]), mul(q, z[j])));
    }
    return r;
}

// Recover successive solution-jet coefficients from the differential equations.
vector<P> tay(I t, vector<I> z, int order) {
    int N = z.size();
    vector<P> p(N, P(order + 1));
    for (int i = 0; i < N; i++) p[i][0] = z[i];
    P tt(order + 1);
    tt[0] = t;
    if (order) tt[1] = I(1);
    for (int k = 0; k < order; k++) {
        auto r = rhs(tt, p);
        for (int i = 0; i < N; i++) p[i][k + 1] = r[i][k] / I(k + 1);
    }
    return p;
}

// Interval evaluation of the right-hand side, including signed profile values.
vector<I> fval(I t, vector<I> z) {
    int N = z.size();
    I d = t * (I(2) - t), w43 = ab(z[0]) * cb(ab(z[0])), f = (I(15) / I(16)) * (w43 * z[0] - z[0]), V = (I(35) / I(16)) * w43 - I(15) / I(16);
    vector<I> fz(N);
    fz[0] = z[1];
    fz[1] = - (I(3) * (I(1) - t) * z[1] + f) / d;
    for (int j = 2; j < N; j += 2) {
        int a = j < 6 ? 4 : 5;
        bool L = j == 2 || j == 6;
        I b = I(L ? 3 + 2 * a : 3) - I(3 + a) * t, q = V - I(a * (a + 4)) / I(4);
        fz[j] = z[j + 1];
        fz[j + 1] = - (b * z[j + 1] + q * z[j]) / d;
    }
    return fz;
}

// Second time derivatives for the low-order Taylor remainder.
vector<I> second(I t, vector<I> z) {
    auto f = fval(t, z);
    int N = z.size();
    I d = t * (I(2) - t), dp = I(2) - I(2) * t, w43 = ab(z[0]) * cb(ab(z[0])), V = I(35) / I(16) * w43 - I(15) / I(16);
    I Vp = I(35) / I(12) * cb(ab(z[0]));
    if (z[0].u <= 0) Vp = - Vp;
    else if (z[0].l < 0) Vp = I(- Vp.u, Vp.u);
    vector<I> ff(N);
    ff[0] = f[1];
    I b = I(3) * (I(1) - t) / d, bp = (- I(3) * d - I(3) * (I(1) - t) * dp) / (d * d);
    I nonlin = I(15) / I(16) * (w43 * z[0] - z[0]);
    ff[1] = - bp * z[1] - b * f[1] - V * z[1] / d + nonlin * dp / (d * d);
    for (int j = 2; j < N; j += 2) {
        int a = j < 6 ? 4 : 5;
        bool L = j == 2 || j == 6;
        I num = I(L ? 3 + 2 * a : 3) - I(3 + a) * t;
        I bb = num / d, bpp = (- I(3 + a) * d - num * dp) / (d * d), qq = (V - I(a * (a + 4)) / I(4)) / d, qp = Vp * z[1] / d - (V - I(a * (a + 4)) / I(4)) * dp / (d * d);
        ff[j] = f[j + 1];
        ff[j + 1] = - bpp * z[j + 1] - bb * f[j + 1] - qp * z[j] - qq * z[j + 1];
    }
    return ff;
}

// Initialize from the regular small-t enclosure and advance to t = 1.
vector<I> integrate(I amp, int N, double step) {
    req(N == 2 || N == 10, "unsupported dimension");
    req(isfinite(step) && step > 0, "invalid step");
    req(cmp(amp.l, Decimal {
        2617, 500
    }) >= 0 && cmp(amp.u, Decimal {
        1309, 250
    }) <= 0, "amplitude outside proved initialization");
    double t = 1e-6;
    req(cmp(t, Decimal {
        1, 1000000
    }) <= 0, "initial time exceeds proved range");
    I eps(t), s = - I(5) / I(16) * (amp * amp * cb(amp) - amp);
    I V = I(35) / I(16) * amp * cb(amp) - I(15) / I(16);
    vector<I> Y(N);
    Y[0] = amp + s * eps + I(- 32.5, 32.5) * eps * eps;
    Y[1] = s + I(- 65, 65) * eps;
    for (int j = 2; j < N; j += 2) {
        int a = j < 6 ? 4 : 5;
        bool L = j == 2 || j == 6;
        I sy = - (V - I(a * (a + 4)) / I(4)) / I(L ? 3 + 2 * a : 3);
        Y[j] = I(1) + sy * eps + I(- 17, 17) * eps * eps;
        Y[j + 1] = sy + I(- 34, 34) * eps;
    }
    uint64_t steps = 0;
    while (t < 1) {
        double h = min({ step, 0.005 * t, 1 - t});
        if (Y[0].l < 0.002) h = min(h, 1e-6);
        double next_t = t + h;
        h = next_t - t;
        grid_check(t, next_t, h);
        I T(t, next_t), H(0, h);
        vector<I> B = Y;
        auto initial = fval(I(t), Y);
        for (int i = 0; i < N; i++) {
            I J = Y[i] + H * initial[i];
            double m = mid(J), r = mag(J - I(m));
            B[i] = I(dn(m - 1.1 * r - 1e-14), up(m + 1.1 * r + 1e-14));
        }
        // Picard inclusion supplies a tube containing each step trajectory.
        bool valid = false;
        for (int tries = 0; tries < 25; tries++) {
            auto F = fval(T, B);
            valid = true;
            for (int i = 0; i < N; i++) {
                I J = Y[i] + H * F[i];
                if (J.l < B[i].l || J.u > B[i].u) {
                    valid = false;
                    double l = min(J.l, B[i].l), u = max(J.u, B[i].u), m = l + (u - l) / 2, r = (u - l) / 2;
                    B[i] = I(dn(m - 1.1 * r - 1e-15), up(m + 1.1 * r + 1e-15));
                }
            }
            if (valid) break;
        }
        if (!valid) throw runtime_error("Picard enclosure failed");
        if (B[1].u >= 0) throw runtime_error("profile monotonicity unverified");
        // Split the current box into a point center and component radii.
        vector<I> M(N);
        vector<double> r(N), E(N);
        for (int i = 0; i < N; i++) {
            M[i] = I(mid(Y[i]));
            req(Y[i].l <= M[i].l && M[i].u <= Y[i].u, "midpoint outside initial box");
            req(B[i].l <= Y[i].l && Y[i].u <= B[i].u, "initial box outside Picard box");
            r[i] = mag(Y[i] - M[i]);
            E[i] = r[i];
        }
        // Bound the absolute Jacobian entries and retain signed diagonal damping.
        vector<vector<double>> K(N, vector<double>(N));
        vector<double> bv(N);
        I d = T * (I(2) - T), w43 = ab(B[0]) * cb(ab(B[0])), VV = I(35) / I(16) * w43 - I(15) / I(16), Vp = I(35) / I(12) * cb(ab(B[0]));
        K[0][1] = 1;
        K[1][0] = mag(VV / d);
        bv[1] = (I(3) * (I(1) - T) / d).l;
        for (int j = 2; j < N; j += 2) {
            int a = j < 6 ? 4 : 5;
            bool L = j == 2 || j == 6;
            K[j][j + 1] = 1;
            K[j + 1][j] = mag((VV - I(a * (a + 4)) / I(4)) / d);
            K[j + 1][0] = mag(Vp * B[j] / d);
            bv[j + 1] = ((I(L ? 3 + 2 * a : 3) - I(3 + a) * T) / d).l;
        }
        for (int i = 1; i < N; i += 2) K[i][i] = max(0., - bv[i]);
        // Enclose the componentwise radius supremum over the step.
        bool errok = false;
        for (int it = 0; it < 100; it++) {
            errok = true;
            vector<double> En = E;
            for (int i = 0; i < N; i++) {
                I sum;
                for (int j = 0; j < N; j++) sum = sum + I(K[i][j]) * I(E[j]);
                double need = (I(r[i]) + I(h) * sum).u;
                if (need > E[i]) {
                    En[i] = up(need * 1.001 + 1e-30);
                    errok = false;
                }
            }
            E = En;
            if (errok) break;
        }
        if (!errok) throw runtime_error("radius sup failed");
        // Advance the center with a Taylor polynomial and an interval remainder.
        vector<I> local(N);
        int order = B[0].l > 0.001 ? 4 : 1;
        if (order == 4) {
            auto point = tay(I(t), M, order), rem = tay(T, B, order + 1);
            for (int i = 0; i < N; i++) {
                I p = point[i][order];
                for (int k = order - 1; k >= 0; k--) p = point[i][k] + I(h) * p;
                I hp(1);
                for (int k = 0; k < order + 1; k++) hp = hp * I(h);
                local[i] = p + hp * rem[i][order + 1];
            }
        } else {
            auto F = fval(I(t), M), D = second(T, B);
            for (int i = 0; i < N; i++) local[i] = M[i] + I(h) * F[i] + I(h) * I(h) / I(2) * D[i];
        }
        // Propagate endpoint radii using the diagonal damping/growth bounds.
        vector<double> out(N);
        for (int i = 0; i < N; i += 2) {
            out[i] = (I(r[i]) + I(h) * I(E[i + 1])).u;
            I force;
            for (int j = 0; j < N; j++) if (j != i + 1) force = force + I(K[i + 1][j]) * I(E[j]);
            I x = I(bv[i + 1]) * I(h), g;
            if (x.l >= 0) {
                if (x.u > 1) throw runtime_error("damping too large");
                g = I(1) - x + x * x / I(2);
                out[i + 1] = (g * I(r[i + 1]) + I(h) * force).u;
            } else {
                I z = - x;
                if (z.u >= 1) throw runtime_error("growth too large");
                g = I(1) + z + z * z / (I(2) * (I(1) - z / I(3)));
                out[i + 1] = (g * (I(r[i + 1]) + I(h) * force)).u;
            }
        }
        for (int i = 0; i < N; i++) {
            req(isfinite(out[i]) && out[i] >= 0, "invalid propagated error radius");
            Y[i] = local[i] + I(- out[i], out[i]);
        }
        t = next_t;
        if (++steps % 10000 == 0) cerr << "t=" << t << " width=" << Y[0].u - Y[0].l << "\n";
        if (!isfinite(Y[0].l) || Y[0].u - Y[0].l > 0.1) throw runtime_error("width explosion");
    }
    req(t == 1, "integration did not reach endpoint");
    req(fegetround() == FE_TONEAREST, "rounding mode changed");
    req(!(fetestexcept(FE_INVALID | FE_DIVBYZERO | FE_OVERFLOW)), "invalid, division-by-zero, or overflow exception");
    cerr << "steps=" << steps << " grid_checks=" << grid_checks << "\n";
#ifdef EXACT_RATIONAL_AUDIT
    cerr << "exact_checks addition=" << add_checks << " multiplication=" << mul_checks << " reciprocal=" << recip_checks << "\n";
#endif
    return Y;
}

// Command-line entry point and endpoint/determinant reporting.
int main(int argc, char * * argv) {
    cout << setprecision(17);
    try {
        arithmetic_environment();
        req(argc == 5, "usage: certificate amplitude_lower amplitude_upper {2|10} positive_step");
        string alo = argv[1], ahi = argv[2];
        Decimal lo = decimal(alo), hi = decimal(ahi);
        req(cmp(lo, hi) <= 0, "reversed exact decimal amplitude interval");
        req(cmp(lo, Decimal {
            2617, 500
        }) >= 0 && cmp(hi, Decimal {
            1309, 250
        }) <= 0, "amplitude decimals outside proved range");
        size_t used = 0;
        double a = stod(alo, & used);
        req(used == alo.size(), "unparsed lower amplitude");
        double b = stod(ahi, & used);
        req(used == ahi.size(), "unparsed upper amplitude");
        req(isfinite(a) && isfinite(b), "nonfinite amplitude");
        I amplitude(dn(a), up(b));
        req(cmp(amplitude.l, lo) <= 0 && cmp(amplitude.u, hi) >= 0, "decimal amplitudes not enclosed exactly");
        string ns = argv[3];
        req(ns == "2" || ns == "10", "dimension must be 2 or 10");
        int n = stoi(ns);
        string hs = argv[4];
        double h = stod(hs, & used);
        req(used == hs.size() && isfinite(h) && h > 0, "invalid positive step");
        auto y = integrate(amplitude, n, h);
        if (n == 2) req(y[0].l > 0 || y[0].u < 0, "shooting endpoint sign not certified");
        for (int i = 0; i < n; i++) cout << i << " [" << y[i].l << "," << y[i].u << "]\n";
        if (n == 10) {
            I d4 = y[2] * y[5] + y[3] * y[4], d5 = y[6] * y[9] + y[7] * y[8];
            req(d4.u < 0 && d5.l > 0, "D4<0<D5 not certified");
            cout << "D4 [" << d4.l << "," << d4.u << "] D5 [" << d5.l << "," << d5.u << "]\n";
        }
    } catch (exception & e) {
        cerr << "FAIL " << e.what() << "\n";
        return 1;
    }
}
