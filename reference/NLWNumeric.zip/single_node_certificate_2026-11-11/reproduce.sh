#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mode="${1:-normal}"
case "$mode" in
  normal) audit_flags=(); audit_libs=() ;;
  exact) audit_flags=(-DEXACT_RATIONAL_AUDIT); audit_libs=(-lgmpxx -lgmp) ;;
  *) echo 'Usage: bash reproduce.sh [normal|exact]' >&2; exit 2 ;;
esac
mkdir -p "build/$mode"
g++ -O2 -std=c++17 -fno-fast-math -ffp-contract=off -frounding-math \
  "${audit_flags[@]}" single_node_certificate.cpp "${audit_libs[@]}" \
  -o "build/$mode/certificate"
"build/$mode/certificate" 5.234683 5.234683 2 0.0002 \
  > "build/$mode/profile_lower.txt" 2> "build/$mode/profile_lower.log"
"build/$mode/certificate" 5.234684 5.234684 2 0.0002 \
  > "build/$mode/profile_upper.txt" 2> "build/$mode/profile_upper.log"
"build/$mode/certificate" 5.234683 5.234684 10 0.0002 \
  > "build/$mode/mode_determinants.txt" 2> "build/$mode/mode_determinants.log"
cmp profile_lower.txt "build/$mode/profile_lower.txt"
cmp profile_upper.txt "build/$mode/profile_upper.txt"
cmp mode_determinants.txt "build/$mode/mode_determinants.txt"
echo "All three $mode runs passed; outputs match the released records."
